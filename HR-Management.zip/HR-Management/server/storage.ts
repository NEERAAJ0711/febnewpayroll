import { 
  type User, 
  type InsertUser, 
  type Company, 
  type InsertCompany,
  type Employee,
  type InsertEmployee,
  type DashboardStats,
  type Attendance,
  type InsertAttendance,
  type LeaveType,
  type InsertLeaveType,
  type LeaveRequest,
  type InsertLeaveRequest,
  type SalaryStructure,
  type InsertSalaryStructure,
  type Payroll,
  type InsertPayroll,
  type Setting,
  type InsertSetting,
  type MasterDepartment,
  type InsertMasterDepartment,
  type MasterDesignation,
  type InsertMasterDesignation,
  type MasterLocation,
  type InsertMasterLocation,
  type EarningHead,
  type InsertEarningHead,
  type DeductionHead,
  type InsertDeductionHead,
  type StatutorySettings,
  type InsertStatutorySettings
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Users
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: Partial<InsertUser>): Promise<User | undefined>;
  deleteUser(id: string): Promise<boolean>;
  getAllUsers(): Promise<User[]>;

  // Companies
  getCompany(id: string): Promise<Company | undefined>;
  createCompany(company: InsertCompany): Promise<Company>;
  updateCompany(id: string, company: Partial<InsertCompany>): Promise<Company | undefined>;
  deleteCompany(id: string): Promise<boolean>;
  getAllCompanies(): Promise<Company[]>;

  // Employees
  getEmployee(id: string): Promise<Employee | undefined>;
  getEmployeesByCompany(companyId: string): Promise<Employee[]>;
  createEmployee(employee: InsertEmployee): Promise<Employee>;
  updateEmployee(id: string, employee: Partial<InsertEmployee>): Promise<Employee | undefined>;
  deleteEmployee(id: string): Promise<boolean>;
  getAllEmployees(): Promise<Employee[]>;

  // Dashboard
  getDashboardStats(): Promise<DashboardStats>;
  getDashboardStatsByCompany(companyId: string): Promise<DashboardStats>;

  // Attendance
  getAttendance(id: string): Promise<Attendance | undefined>;
  getAttendanceByEmployee(employeeId: string, date?: string): Promise<Attendance[]>;
  getAttendanceByDate(companyId: string, date: string): Promise<Attendance[]>;
  createAttendance(attendance: InsertAttendance): Promise<Attendance>;
  updateAttendance(id: string, attendance: Partial<InsertAttendance>): Promise<Attendance | undefined>;
  deleteAttendance(id: string): Promise<boolean>;
  getAllAttendance(): Promise<Attendance[]>;

  // Leave Types
  getLeaveType(id: string): Promise<LeaveType | undefined>;
  getLeaveTypesByCompany(companyId: string | null): Promise<LeaveType[]>;
  createLeaveType(leaveType: InsertLeaveType): Promise<LeaveType>;
  updateLeaveType(id: string, leaveType: Partial<InsertLeaveType>): Promise<LeaveType | undefined>;
  deleteLeaveType(id: string): Promise<boolean>;
  getAllLeaveTypes(): Promise<LeaveType[]>;

  // Leave Requests
  getLeaveRequest(id: string): Promise<LeaveRequest | undefined>;
  getLeaveRequestsByEmployee(employeeId: string): Promise<LeaveRequest[]>;
  getLeaveRequestsByCompany(companyId: string): Promise<LeaveRequest[]>;
  createLeaveRequest(leaveRequest: InsertLeaveRequest): Promise<LeaveRequest>;
  updateLeaveRequest(id: string, leaveRequest: Partial<LeaveRequest>): Promise<LeaveRequest | undefined>;
  deleteLeaveRequest(id: string): Promise<boolean>;
  getAllLeaveRequests(): Promise<LeaveRequest[]>;

  // Salary Structures
  getSalaryStructure(id: string): Promise<SalaryStructure | undefined>;
  getSalaryStructureByEmployee(employeeId: string): Promise<SalaryStructure | undefined>;
  createSalaryStructure(salaryStructure: InsertSalaryStructure): Promise<SalaryStructure>;
  updateSalaryStructure(id: string, salaryStructure: Partial<InsertSalaryStructure>): Promise<SalaryStructure | undefined>;
  deleteSalaryStructure(id: string): Promise<boolean>;
  getAllSalaryStructures(): Promise<SalaryStructure[]>;

  // Payroll
  getPayroll(id: string): Promise<Payroll | undefined>;
  getPayrollByEmployee(employeeId: string): Promise<Payroll[]>;
  getPayrollByMonth(companyId: string, month: string, year: number): Promise<Payroll[]>;
  createPayroll(payroll: InsertPayroll): Promise<Payroll>;
  updatePayroll(id: string, payroll: Partial<InsertPayroll>): Promise<Payroll | undefined>;
  deletePayroll(id: string): Promise<boolean>;
  getAllPayroll(): Promise<Payroll[]>;

  // Settings
  getSetting(id: string): Promise<Setting | undefined>;
  getSettingByKey(companyId: string | null, key: string): Promise<Setting | undefined>;
  getSettingsByCategory(companyId: string | null, category: string): Promise<Setting[]>;
  createSetting(setting: InsertSetting): Promise<Setting>;
  updateSetting(id: string, setting: Partial<InsertSetting>): Promise<Setting | undefined>;
  deleteSetting(id: string): Promise<boolean>;
  getAllSettings(): Promise<Setting[]>;

  // Master Departments
  getMasterDepartment(id: string): Promise<MasterDepartment | undefined>;
  getMasterDepartmentsByCompany(companyId: string): Promise<MasterDepartment[]>;
  createMasterDepartment(dept: InsertMasterDepartment): Promise<MasterDepartment>;
  updateMasterDepartment(id: string, dept: Partial<InsertMasterDepartment>): Promise<MasterDepartment | undefined>;
  deleteMasterDepartment(id: string): Promise<boolean>;

  // Master Designations
  getMasterDesignation(id: string): Promise<MasterDesignation | undefined>;
  getMasterDesignationsByCompany(companyId: string): Promise<MasterDesignation[]>;
  createMasterDesignation(desg: InsertMasterDesignation): Promise<MasterDesignation>;
  updateMasterDesignation(id: string, desg: Partial<InsertMasterDesignation>): Promise<MasterDesignation | undefined>;
  deleteMasterDesignation(id: string): Promise<boolean>;

  // Master Locations
  getMasterLocation(id: string): Promise<MasterLocation | undefined>;
  getMasterLocationsByCompany(companyId: string): Promise<MasterLocation[]>;
  createMasterLocation(loc: InsertMasterLocation): Promise<MasterLocation>;
  updateMasterLocation(id: string, loc: Partial<InsertMasterLocation>): Promise<MasterLocation | undefined>;
  deleteMasterLocation(id: string): Promise<boolean>;

  // Earning Heads
  getEarningHead(id: string): Promise<EarningHead | undefined>;
  getEarningHeadsByCompany(companyId: string): Promise<EarningHead[]>;
  createEarningHead(head: InsertEarningHead): Promise<EarningHead>;
  updateEarningHead(id: string, head: Partial<InsertEarningHead>): Promise<EarningHead | undefined>;
  deleteEarningHead(id: string): Promise<boolean>;

  // Deduction Heads
  getDeductionHead(id: string): Promise<DeductionHead | undefined>;
  getDeductionHeadsByCompany(companyId: string): Promise<DeductionHead[]>;
  createDeductionHead(head: InsertDeductionHead): Promise<DeductionHead>;
  updateDeductionHead(id: string, head: Partial<InsertDeductionHead>): Promise<DeductionHead | undefined>;
  deleteDeductionHead(id: string): Promise<boolean>;

  // Statutory Settings
  getStatutorySettings(id: string): Promise<StatutorySettings | undefined>;
  getStatutorySettingsByCompany(companyId: string): Promise<StatutorySettings | undefined>;
  createStatutorySettings(settings: InsertStatutorySettings): Promise<StatutorySettings>;
  updateStatutorySettings(id: string, settings: Partial<InsertStatutorySettings>): Promise<StatutorySettings | undefined>;
  deleteStatutorySettings(id: string): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private companies: Map<string, Company>;
  private employees: Map<string, Employee>;
  private attendanceRecords: Map<string, Attendance>;
  private leaveTypesMap: Map<string, LeaveType>;
  private leaveRequestsMap: Map<string, LeaveRequest>;
  private salaryStructuresMap: Map<string, SalaryStructure>;
  private payrollRecords: Map<string, Payroll>;
  private settingsMap: Map<string, Setting>;
  private masterDepartmentsMap: Map<string, MasterDepartment>;
  private masterDesignationsMap: Map<string, MasterDesignation>;
  private masterLocationsMap: Map<string, MasterLocation>;
  private earningHeadsMap: Map<string, EarningHead>;
  private deductionHeadsMap: Map<string, DeductionHead>;
  private statutorySettingsMap: Map<string, StatutorySettings>;

  constructor() {
    this.users = new Map();
    this.companies = new Map();
    this.employees = new Map();
    this.attendanceRecords = new Map();
    this.leaveTypesMap = new Map();
    this.leaveRequestsMap = new Map();
    this.salaryStructuresMap = new Map();
    this.payrollRecords = new Map();
    this.settingsMap = new Map();
    this.masterDepartmentsMap = new Map();
    this.masterDesignationsMap = new Map();
    this.masterLocationsMap = new Map();
    this.earningHeadsMap = new Map();
    this.deductionHeadsMap = new Map();
    this.statutorySettingsMap = new Map();

    // Initialize default leave types
    const defaultLeaveTypes = [
      { name: "Casual Leave", code: "CL", daysPerYear: 12, carryForward: false },
      { name: "Sick Leave", code: "SL", daysPerYear: 12, carryForward: true, maxCarryForward: 6 },
      { name: "Privilege Leave", code: "PL", daysPerYear: 15, carryForward: true, maxCarryForward: 30 },
      { name: "Maternity Leave", code: "ML", daysPerYear: 182, carryForward: false },
      { name: "Paternity Leave", code: "PTL", daysPerYear: 15, carryForward: false },
    ];
    
    defaultLeaveTypes.forEach(lt => {
      const id = randomUUID();
      this.leaveTypesMap.set(id, {
        id,
        companyId: null,
        name: lt.name,
        code: lt.code,
        daysPerYear: lt.daysPerYear,
        carryForward: lt.carryForward,
        maxCarryForward: lt.maxCarryForward || 0,
        description: null,
        status: "active"
      });
    });

    // Create default super admin user
    const adminId = randomUUID();
    this.users.set(adminId, {
      id: adminId,
      username: "admin",
      email: "admin@hrms.com",
      password: "admin123",
      firstName: "Super",
      lastName: "Admin",
      role: "super_admin",
      companyId: null,
      status: "active",
      lastLogin: null
    });
  }

  // User methods
  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { 
      ...insertUser, 
      id,
      firstName: insertUser.firstName || "",
      lastName: insertUser.lastName || "",
      role: insertUser.role || "employee",
      status: insertUser.status || "active",
      companyId: insertUser.companyId || null,
      lastLogin: null
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: string, updates: Partial<InsertUser>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async deleteUser(id: string): Promise<boolean> {
    return this.users.delete(id);
  }

  async getAllUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Company methods
  async getCompany(id: string): Promise<Company | undefined> {
    return this.companies.get(id);
  }

  async createCompany(insertCompany: InsertCompany): Promise<Company> {
    const id = randomUUID();
    const company: Company = { 
      ...insertCompany, 
      id,
      status: insertCompany.status || "active",
      cin: insertCompany.cin || null,
      pan: insertCompany.pan || null,
      gstin: insertCompany.gstin || null,
      pfCode: insertCompany.pfCode || null,
      esiCode: insertCompany.esiCode || null,
      ptState: insertCompany.ptState || null,
      lwfState: insertCompany.lwfState || null,
      registeredAddress: insertCompany.registeredAddress || null,
      logo: insertCompany.logo || null,
      financialYear: insertCompany.financialYear || null,
    };
    this.companies.set(id, company);
    return company;
  }

  async updateCompany(id: string, updates: Partial<InsertCompany>): Promise<Company | undefined> {
    const company = this.companies.get(id);
    if (!company) return undefined;
    
    const updatedCompany = { ...company, ...updates };
    this.companies.set(id, updatedCompany);
    return updatedCompany;
  }

  async deleteCompany(id: string): Promise<boolean> {
    // Also delete related employees
    const employees = Array.from(this.employees.values());
    for (const emp of employees) {
      if (emp.companyId === id) {
        this.employees.delete(emp.id);
      }
    }
    return this.companies.delete(id);
  }

  async getAllCompanies(): Promise<Company[]> {
    return Array.from(this.companies.values());
  }

  // Employee methods
  async getEmployee(id: string): Promise<Employee | undefined> {
    return this.employees.get(id);
  }

  async getEmployeesByCompany(companyId: string): Promise<Employee[]> {
    return Array.from(this.employees.values()).filter(
      (emp) => emp.companyId === companyId
    );
  }

  async createEmployee(insertEmployee: InsertEmployee): Promise<Employee> {
    const id = randomUUID();
    const employee: Employee = { 
      ...insertEmployee, 
      id,
      status: insertEmployee.status || "active",
      userId: insertEmployee.userId || null,
      gender: insertEmployee.gender || null,
      dateOfBirth: insertEmployee.dateOfBirth || null,
      mobileNumber: insertEmployee.mobileNumber || null,
      officialEmail: insertEmployee.officialEmail || null,
      department: insertEmployee.department || null,
      designation: insertEmployee.designation || null,
      reportingManager: insertEmployee.reportingManager || null,
      location: insertEmployee.location || null,
      employmentType: insertEmployee.employmentType || "permanent",
      grossSalary: insertEmployee.grossSalary || null,
      paymentMode: insertEmployee.paymentMode || null,
      pfApplicable: insertEmployee.pfApplicable || false,
      uan: insertEmployee.uan || null,
      esiApplicable: insertEmployee.esiApplicable || false,
      esiNumber: insertEmployee.esiNumber || null,
      ptState: insertEmployee.ptState || null,
      lwfApplicable: insertEmployee.lwfApplicable || false,
      bankAccount: insertEmployee.bankAccount || null,
      ifsc: insertEmployee.ifsc || null,
      pan: insertEmployee.pan || null,
      aadhaar: insertEmployee.aadhaar || null,
    };
    this.employees.set(id, employee);
    return employee;
  }

  async updateEmployee(id: string, updates: Partial<InsertEmployee>): Promise<Employee | undefined> {
    const employee = this.employees.get(id);
    if (!employee) return undefined;
    
    const updatedEmployee = { ...employee, ...updates };
    this.employees.set(id, updatedEmployee);
    return updatedEmployee;
  }

  async deleteEmployee(id: string): Promise<boolean> {
    return this.employees.delete(id);
  }

  async getAllEmployees(): Promise<Employee[]> {
    return Array.from(this.employees.values());
  }

  // Dashboard methods
  async getDashboardStats(): Promise<DashboardStats> {
    const companies = Array.from(this.companies.values());
    const employees = Array.from(this.employees.values());
    const users = Array.from(this.users.values());

    const activeEmployees = employees.filter(e => e.status === "active");

    // Department distribution
    const deptMap = new Map<string, number>();
    for (const emp of employees) {
      const dept = emp.department || "Unassigned";
      deptMap.set(dept, (deptMap.get(dept) || 0) + 1);
    }
    const departmentDistribution = Array.from(deptMap.entries())
      .map(([department, count]) => ({ department, count }))
      .sort((a, b) => b.count - a.count);

    // Recent employees (last 5)
    const recentEmployees = employees.slice(-5).reverse();

    return {
      totalCompanies: companies.length,
      totalEmployees: employees.length,
      totalUsers: users.length,
      activeEmployees: activeEmployees.length,
      departmentDistribution,
      recentEmployees,
    };
  }

  async getDashboardStatsByCompany(companyId: string): Promise<DashboardStats> {
    const employees = Array.from(this.employees.values()).filter(e => e.companyId === companyId);
    const users = Array.from(this.users.values()).filter(u => u.companyId === companyId);

    const activeEmployees = employees.filter(e => e.status === "active");

    // Department distribution for this company only
    const deptMap = new Map<string, number>();
    for (const emp of employees) {
      const dept = emp.department || "Unassigned";
      deptMap.set(dept, (deptMap.get(dept) || 0) + 1);
    }
    const departmentDistribution = Array.from(deptMap.entries())
      .map(([department, count]) => ({ department, count }))
      .sort((a, b) => b.count - a.count);

    // Recent employees (last 5) for this company
    const recentEmployees = employees.slice(-5).reverse();

    return {
      totalCompanies: 1, // Only this company
      totalEmployees: employees.length,
      totalUsers: users.length,
      activeEmployees: activeEmployees.length,
      departmentDistribution,
      recentEmployees,
    };
  }

  // Attendance methods
  async getAttendance(id: string): Promise<Attendance | undefined> {
    return this.attendanceRecords.get(id);
  }

  async getAttendanceByEmployee(employeeId: string, date?: string): Promise<Attendance[]> {
    return Array.from(this.attendanceRecords.values()).filter(
      (a) => a.employeeId === employeeId && (!date || a.date === date)
    );
  }

  async getAttendanceByDate(companyId: string, date: string): Promise<Attendance[]> {
    return Array.from(this.attendanceRecords.values()).filter(
      (a) => a.companyId === companyId && a.date === date
    );
  }

  async createAttendance(insertAttendance: InsertAttendance): Promise<Attendance> {
    const id = randomUUID();
    const attendance: Attendance = {
      ...insertAttendance,
      id,
      status: insertAttendance.status || "present",
      clockIn: insertAttendance.clockIn || null,
      clockOut: insertAttendance.clockOut || null,
      workHours: insertAttendance.workHours || null,
      notes: insertAttendance.notes || null,
    };
    this.attendanceRecords.set(id, attendance);
    return attendance;
  }

  async updateAttendance(id: string, updates: Partial<InsertAttendance>): Promise<Attendance | undefined> {
    const attendance = this.attendanceRecords.get(id);
    if (!attendance) return undefined;
    const updatedAttendance = { ...attendance, ...updates };
    this.attendanceRecords.set(id, updatedAttendance);
    return updatedAttendance;
  }

  async deleteAttendance(id: string): Promise<boolean> {
    return this.attendanceRecords.delete(id);
  }

  async getAllAttendance(): Promise<Attendance[]> {
    return Array.from(this.attendanceRecords.values());
  }

  // Leave Type methods
  async getLeaveType(id: string): Promise<LeaveType | undefined> {
    return this.leaveTypesMap.get(id);
  }

  async getLeaveTypesByCompany(companyId: string | null): Promise<LeaveType[]> {
    return Array.from(this.leaveTypesMap.values()).filter(
      (lt) => lt.companyId === null || lt.companyId === companyId
    );
  }

  async createLeaveType(insertLeaveType: InsertLeaveType): Promise<LeaveType> {
    const id = randomUUID();
    const leaveType: LeaveType = {
      ...insertLeaveType,
      id,
      status: insertLeaveType.status || "active",
      daysPerYear: insertLeaveType.daysPerYear || 12,
      companyId: insertLeaveType.companyId || null,
      carryForward: insertLeaveType.carryForward || false,
      maxCarryForward: insertLeaveType.maxCarryForward || 0,
      description: insertLeaveType.description || null,
    };
    this.leaveTypesMap.set(id, leaveType);
    return leaveType;
  }

  async updateLeaveType(id: string, updates: Partial<InsertLeaveType>): Promise<LeaveType | undefined> {
    const leaveType = this.leaveTypesMap.get(id);
    if (!leaveType) return undefined;
    const updatedLeaveType = { ...leaveType, ...updates };
    this.leaveTypesMap.set(id, updatedLeaveType);
    return updatedLeaveType;
  }

  async deleteLeaveType(id: string): Promise<boolean> {
    return this.leaveTypesMap.delete(id);
  }

  async getAllLeaveTypes(): Promise<LeaveType[]> {
    return Array.from(this.leaveTypesMap.values());
  }

  // Leave Request methods
  async getLeaveRequest(id: string): Promise<LeaveRequest | undefined> {
    return this.leaveRequestsMap.get(id);
  }

  async getLeaveRequestsByEmployee(employeeId: string): Promise<LeaveRequest[]> {
    return Array.from(this.leaveRequestsMap.values()).filter(
      (lr) => lr.employeeId === employeeId
    );
  }

  async getLeaveRequestsByCompany(companyId: string): Promise<LeaveRequest[]> {
    return Array.from(this.leaveRequestsMap.values()).filter(
      (lr) => lr.companyId === companyId
    );
  }

  async createLeaveRequest(insertLeaveRequest: InsertLeaveRequest): Promise<LeaveRequest> {
    const id = randomUUID();
    const leaveRequest: LeaveRequest = {
      ...insertLeaveRequest,
      id,
      status: insertLeaveRequest.status || "pending",
      reason: insertLeaveRequest.reason || null,
      approvedBy: null,
      approvedAt: null,
    };
    this.leaveRequestsMap.set(id, leaveRequest);
    return leaveRequest;
  }

  async updateLeaveRequest(id: string, updates: Partial<LeaveRequest>): Promise<LeaveRequest | undefined> {
    const leaveRequest = this.leaveRequestsMap.get(id);
    if (!leaveRequest) return undefined;
    const updatedLeaveRequest = { ...leaveRequest, ...updates };
    this.leaveRequestsMap.set(id, updatedLeaveRequest);
    return updatedLeaveRequest;
  }

  async deleteLeaveRequest(id: string): Promise<boolean> {
    return this.leaveRequestsMap.delete(id);
  }

  async getAllLeaveRequests(): Promise<LeaveRequest[]> {
    return Array.from(this.leaveRequestsMap.values());
  }

  // Salary Structure methods
  async getSalaryStructure(id: string): Promise<SalaryStructure | undefined> {
    return this.salaryStructuresMap.get(id);
  }

  async getSalaryStructureByEmployee(employeeId: string): Promise<SalaryStructure | undefined> {
    return Array.from(this.salaryStructuresMap.values()).find(
      (ss) => ss.employeeId === employeeId && ss.status === "active"
    );
  }

  async createSalaryStructure(insertSalaryStructure: InsertSalaryStructure): Promise<SalaryStructure> {
    const id = randomUUID();
    const salaryStructure: SalaryStructure = {
      ...insertSalaryStructure,
      id,
      status: insertSalaryStructure.status || "active",
      hra: insertSalaryStructure.hra || 0,
      conveyance: insertSalaryStructure.conveyance || 0,
      medicalAllowance: insertSalaryStructure.medicalAllowance || 0,
      specialAllowance: insertSalaryStructure.specialAllowance || 0,
      otherAllowances: insertSalaryStructure.otherAllowances || 0,
      pfEmployee: insertSalaryStructure.pfEmployee || 0,
      pfEmployer: insertSalaryStructure.pfEmployer || 0,
      esi: insertSalaryStructure.esi || 0,
      professionalTax: insertSalaryStructure.professionalTax || 0,
      tds: insertSalaryStructure.tds || 0,
      otherDeductions: insertSalaryStructure.otherDeductions || 0,
    };
    this.salaryStructuresMap.set(id, salaryStructure);
    return salaryStructure;
  }

  async updateSalaryStructure(id: string, updates: Partial<InsertSalaryStructure>): Promise<SalaryStructure | undefined> {
    const salaryStructure = this.salaryStructuresMap.get(id);
    if (!salaryStructure) return undefined;
    const updatedSalaryStructure = { ...salaryStructure, ...updates };
    this.salaryStructuresMap.set(id, updatedSalaryStructure);
    return updatedSalaryStructure;
  }

  async deleteSalaryStructure(id: string): Promise<boolean> {
    return this.salaryStructuresMap.delete(id);
  }

  async getAllSalaryStructures(): Promise<SalaryStructure[]> {
    return Array.from(this.salaryStructuresMap.values());
  }

  // Payroll methods
  async getPayroll(id: string): Promise<Payroll | undefined> {
    return this.payrollRecords.get(id);
  }

  async getPayrollByEmployee(employeeId: string): Promise<Payroll[]> {
    return Array.from(this.payrollRecords.values()).filter(
      (p) => p.employeeId === employeeId
    );
  }

  async getPayrollByMonth(companyId: string, month: string, year: number): Promise<Payroll[]> {
    return Array.from(this.payrollRecords.values()).filter(
      (p) => p.companyId === companyId && p.month === month && p.year === year
    );
  }

  async createPayroll(insertPayroll: InsertPayroll): Promise<Payroll> {
    const id = randomUUID();
    const payroll: Payroll = {
      ...insertPayroll,
      id,
      status: insertPayroll.status || "draft",
      leaveDays: insertPayroll.leaveDays || 0,
      paidOn: insertPayroll.paidOn || null,
    };
    this.payrollRecords.set(id, payroll);
    return payroll;
  }

  async updatePayroll(id: string, updates: Partial<InsertPayroll>): Promise<Payroll | undefined> {
    const payroll = this.payrollRecords.get(id);
    if (!payroll) return undefined;
    const updatedPayroll = { ...payroll, ...updates };
    this.payrollRecords.set(id, updatedPayroll);
    return updatedPayroll;
  }

  async deletePayroll(id: string): Promise<boolean> {
    return this.payrollRecords.delete(id);
  }

  async getAllPayroll(): Promise<Payroll[]> {
    return Array.from(this.payrollRecords.values());
  }

  // Settings methods
  async getSetting(id: string): Promise<Setting | undefined> {
    return this.settingsMap.get(id);
  }

  async getSettingByKey(companyId: string | null, key: string): Promise<Setting | undefined> {
    return Array.from(this.settingsMap.values()).find(
      (s) => s.companyId === companyId && s.key === key
    );
  }

  async getSettingsByCategory(companyId: string | null, category: string): Promise<Setting[]> {
    return Array.from(this.settingsMap.values()).filter(
      (s) => (s.companyId === null || s.companyId === companyId) && s.category === category
    );
  }

  async createSetting(insertSetting: InsertSetting): Promise<Setting> {
    const id = randomUUID();
    const setting: Setting = {
      ...insertSetting,
      id,
      companyId: insertSetting.companyId || null,
      value: insertSetting.value || null,
    };
    this.settingsMap.set(id, setting);
    return setting;
  }

  async updateSetting(id: string, updates: Partial<InsertSetting>): Promise<Setting | undefined> {
    const setting = this.settingsMap.get(id);
    if (!setting) return undefined;
    const updatedSetting = { ...setting, ...updates };
    this.settingsMap.set(id, updatedSetting);
    return updatedSetting;
  }

  async deleteSetting(id: string): Promise<boolean> {
    return this.settingsMap.delete(id);
  }

  async getAllSettings(): Promise<Setting[]> {
    return Array.from(this.settingsMap.values());
  }

  // Master Departments methods
  async getMasterDepartment(id: string): Promise<MasterDepartment | undefined> {
    return this.masterDepartmentsMap.get(id);
  }

  async getMasterDepartmentsByCompany(companyId: string): Promise<MasterDepartment[]> {
    return Array.from(this.masterDepartmentsMap.values()).filter(
      (d) => d.companyId === companyId
    );
  }

  async createMasterDepartment(insertDept: InsertMasterDepartment): Promise<MasterDepartment> {
    const id = randomUUID();
    const dept: MasterDepartment = {
      ...insertDept,
      id,
      code: insertDept.code || null,
      description: insertDept.description || null,
      status: insertDept.status || "active",
    };
    this.masterDepartmentsMap.set(id, dept);
    return dept;
  }

  async updateMasterDepartment(id: string, updates: Partial<InsertMasterDepartment>): Promise<MasterDepartment | undefined> {
    const dept = this.masterDepartmentsMap.get(id);
    if (!dept) return undefined;
    const updated = { ...dept, ...updates };
    this.masterDepartmentsMap.set(id, updated);
    return updated;
  }

  async deleteMasterDepartment(id: string): Promise<boolean> {
    return this.masterDepartmentsMap.delete(id);
  }

  // Master Designations methods
  async getMasterDesignation(id: string): Promise<MasterDesignation | undefined> {
    return this.masterDesignationsMap.get(id);
  }

  async getMasterDesignationsByCompany(companyId: string): Promise<MasterDesignation[]> {
    return Array.from(this.masterDesignationsMap.values()).filter(
      (d) => d.companyId === companyId
    );
  }

  async createMasterDesignation(insertDesg: InsertMasterDesignation): Promise<MasterDesignation> {
    const id = randomUUID();
    const desg: MasterDesignation = {
      ...insertDesg,
      id,
      code: insertDesg.code || null,
      level: insertDesg.level || 1,
      description: insertDesg.description || null,
      status: insertDesg.status || "active",
    };
    this.masterDesignationsMap.set(id, desg);
    return desg;
  }

  async updateMasterDesignation(id: string, updates: Partial<InsertMasterDesignation>): Promise<MasterDesignation | undefined> {
    const desg = this.masterDesignationsMap.get(id);
    if (!desg) return undefined;
    const updated = { ...desg, ...updates };
    this.masterDesignationsMap.set(id, updated);
    return updated;
  }

  async deleteMasterDesignation(id: string): Promise<boolean> {
    return this.masterDesignationsMap.delete(id);
  }

  // Master Locations methods
  async getMasterLocation(id: string): Promise<MasterLocation | undefined> {
    return this.masterLocationsMap.get(id);
  }

  async getMasterLocationsByCompany(companyId: string): Promise<MasterLocation[]> {
    return Array.from(this.masterLocationsMap.values()).filter(
      (l) => l.companyId === companyId
    );
  }

  async createMasterLocation(insertLoc: InsertMasterLocation): Promise<MasterLocation> {
    const id = randomUUID();
    const loc: MasterLocation = {
      ...insertLoc,
      id,
      code: insertLoc.code || null,
      address: insertLoc.address || null,
      city: insertLoc.city || null,
      state: insertLoc.state || null,
      country: insertLoc.country || "India",
      status: insertLoc.status || "active",
    };
    this.masterLocationsMap.set(id, loc);
    return loc;
  }

  async updateMasterLocation(id: string, updates: Partial<InsertMasterLocation>): Promise<MasterLocation | undefined> {
    const loc = this.masterLocationsMap.get(id);
    if (!loc) return undefined;
    const updated = { ...loc, ...updates };
    this.masterLocationsMap.set(id, updated);
    return updated;
  }

  async deleteMasterLocation(id: string): Promise<boolean> {
    return this.masterLocationsMap.delete(id);
  }

  // Earning Heads methods
  async getEarningHead(id: string): Promise<EarningHead | undefined> {
    return this.earningHeadsMap.get(id);
  }

  async getEarningHeadsByCompany(companyId: string): Promise<EarningHead[]> {
    return Array.from(this.earningHeadsMap.values()).filter(
      (h) => h.companyId === companyId
    );
  }

  async createEarningHead(insertHead: InsertEarningHead): Promise<EarningHead> {
    const id = randomUUID();
    const head: EarningHead = {
      ...insertHead,
      id,
      type: insertHead.type || "fixed",
      calculationBase: insertHead.calculationBase || null,
      percentage: insertHead.percentage || 0,
      isTaxable: insertHead.isTaxable ?? true,
      isPartOfCTC: insertHead.isPartOfCTC ?? true,
      status: insertHead.status || "active",
    };
    this.earningHeadsMap.set(id, head);
    return head;
  }

  async updateEarningHead(id: string, updates: Partial<InsertEarningHead>): Promise<EarningHead | undefined> {
    const head = this.earningHeadsMap.get(id);
    if (!head) return undefined;
    const updated = { ...head, ...updates };
    this.earningHeadsMap.set(id, updated);
    return updated;
  }

  async deleteEarningHead(id: string): Promise<boolean> {
    return this.earningHeadsMap.delete(id);
  }

  // Deduction Heads methods
  async getDeductionHead(id: string): Promise<DeductionHead | undefined> {
    return this.deductionHeadsMap.get(id);
  }

  async getDeductionHeadsByCompany(companyId: string): Promise<DeductionHead[]> {
    return Array.from(this.deductionHeadsMap.values()).filter(
      (h) => h.companyId === companyId
    );
  }

  async createDeductionHead(insertHead: InsertDeductionHead): Promise<DeductionHead> {
    const id = randomUUID();
    const head: DeductionHead = {
      ...insertHead,
      id,
      type: insertHead.type || "fixed",
      calculationBase: insertHead.calculationBase || null,
      percentage: insertHead.percentage || 0,
      isStatutory: insertHead.isStatutory ?? false,
      status: insertHead.status || "active",
    };
    this.deductionHeadsMap.set(id, head);
    return head;
  }

  async updateDeductionHead(id: string, updates: Partial<InsertDeductionHead>): Promise<DeductionHead | undefined> {
    const head = this.deductionHeadsMap.get(id);
    if (!head) return undefined;
    const updated = { ...head, ...updates };
    this.deductionHeadsMap.set(id, updated);
    return updated;
  }

  async deleteDeductionHead(id: string): Promise<boolean> {
    return this.deductionHeadsMap.delete(id);
  }

  // Statutory Settings methods
  async getStatutorySettings(id: string): Promise<StatutorySettings | undefined> {
    return this.statutorySettingsMap.get(id);
  }

  async getStatutorySettingsByCompany(companyId: string): Promise<StatutorySettings | undefined> {
    return Array.from(this.statutorySettingsMap.values()).find(
      (s) => s.companyId === companyId
    );
  }

  async createStatutorySettings(insertSettings: InsertStatutorySettings): Promise<StatutorySettings> {
    const id = randomUUID();
    const settings: StatutorySettings = {
      ...insertSettings,
      id,
      pfEmployeePercent: insertSettings.pfEmployeePercent ?? 12,
      pfEmployerPercent: insertSettings.pfEmployerPercent ?? 12,
      pfWageCeiling: insertSettings.pfWageCeiling ?? 15000,
      pfEnabled: insertSettings.pfEnabled ?? true,
      esicEmployeePercent: insertSettings.esicEmployeePercent ?? 75,
      esicEmployerPercent: insertSettings.esicEmployerPercent ?? 325,
      esicWageCeiling: insertSettings.esicWageCeiling ?? 21000,
      esicEnabled: insertSettings.esicEnabled ?? true,
      lwfEmployeeAmount: insertSettings.lwfEmployeeAmount ?? 0,
      lwfEmployerAmount: insertSettings.lwfEmployerAmount ?? 0,
      lwfEnabled: insertSettings.lwfEnabled ?? false,
      ptMaxAmount: insertSettings.ptMaxAmount ?? 200,
      ptEnabled: insertSettings.ptEnabled ?? true,
      ptState: insertSettings.ptState || null,
    };
    this.statutorySettingsMap.set(id, settings);
    return settings;
  }

  async updateStatutorySettings(id: string, updates: Partial<InsertStatutorySettings>): Promise<StatutorySettings | undefined> {
    const settings = this.statutorySettingsMap.get(id);
    if (!settings) return undefined;
    const updated = { ...settings, ...updates };
    this.statutorySettingsMap.set(id, updated);
    return updated;
  }

  async deleteStatutorySettings(id: string): Promise<boolean> {
    return this.statutorySettingsMap.delete(id);
  }
}

export const storage = new MemStorage();
