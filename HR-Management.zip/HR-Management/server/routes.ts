import type { Express, Request, Response, NextFunction } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertCompanySchema, 
  insertUserSchema, 
  insertEmployeeSchema,
  insertAttendanceSchema,
  insertLeaveTypeSchema,
  insertLeaveRequestSchema,
  insertSalaryStructureSchema,
  insertPayrollSchema,
  insertSettingSchema,
  insertMasterDepartmentSchema,
  insertMasterDesignationSchema,
  insertMasterLocationSchema,
  insertEarningHeadSchema,
  insertDeductionHeadSchema,
  insertStatutorySettingsSchema
} from "@shared/schema";
import { z } from "zod";

// Extend Express Request type for session
declare module "express-session" {
  interface SessionData {
    userId?: string;
  }
}

// Role hierarchy and permissions
const ROLE_HIERARCHY: Record<string, number> = {
  "super_admin": 100,
  "company_admin": 80,
  "hr_admin": 60,
  "recruiter": 40,
  "manager": 30,
  "employee": 10,
};

const MODULE_ACCESS: Record<string, string[]> = {
  companies: ["super_admin"],
  users: ["super_admin", "company_admin"],
  employees: ["super_admin", "company_admin", "hr_admin", "manager"],
  attendance: ["super_admin", "company_admin", "hr_admin", "manager", "employee"],
  leave: ["super_admin", "company_admin", "hr_admin", "manager", "employee"],
  payroll: ["super_admin", "company_admin", "hr_admin"],
  settings: ["super_admin", "company_admin"],
  masters: ["super_admin", "company_admin", "hr_admin"],
};

// Authentication middleware
const requireAuth = async (req: Request, res: Response, next: NextFunction) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: "Authentication required" });
  }
  const user = await storage.getUser(req.session.userId);
  if (!user) {
    return res.status(401).json({ error: "User not found" });
  }
  (req as any).user = user;
  next();
};

// Role-based access middleware
const requireRole = (...allowedRoles: string[]) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user;
    if (!user) {
      return res.status(401).json({ error: "Authentication required" });
    }
    if (!allowedRoles.includes(user.role)) {
      return res.status(403).json({ error: "Access denied. Insufficient permissions." });
    }
    next();
  };
};

// Module access middleware
const requireModuleAccess = (module: string) => {
  return async (req: Request, res: Response, next: NextFunction) => {
    const user = (req as any).user;
    if (!user) {
      return res.status(401).json({ error: "Authentication required" });
    }
    const allowedRoles = MODULE_ACCESS[module] || [];
    if (!allowedRoles.includes(user.role)) {
      return res.status(403).json({ error: `Access denied to ${module} module.` });
    }
    next();
  };
};

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {

  // ===== Authentication =====
  app.post("/api/auth/login", async (req, res) => {
    try {
      const { username, password } = req.body;
      
      if (!username || !password) {
        return res.status(400).json({ error: "Username and password are required" });
      }

      const user = await storage.getUserByUsername(username);
      if (!user || user.password !== password) {
        return res.status(401).json({ error: "Invalid username or password" });
      }

      // Set session
      req.session.userId = user.id;
      
      // Update last login
      await storage.updateUser(user.id, { lastLogin: new Date().toISOString() } as any);

      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "Login failed" });
    }
  });

  app.post("/api/auth/signup", async (req, res) => {
    try {
      const signupSchema = z.object({
        username: z.string().min(3),
        email: z.string().email(),
        password: z.string().min(6),
        firstName: z.string().min(1),
        lastName: z.string().min(1),
      });

      const data = signupSchema.parse(req.body);

      // Check if username exists
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already exists" });
      }

      // Check if email exists
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already exists" });
      }

      // Create user with viewer role by default
      const user = await storage.createUser({
        username: data.username,
        email: data.email,
        password: data.password,
        role: "employee",
        status: "active",
        firstName: data.firstName,
        lastName: data.lastName,
      });

      // Set session
      req.session.userId = user.id;

      const { password: _, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Signup failed" });
    }
  });

  app.get("/api/auth/me", async (req, res) => {
    try {
      if (!req.session.userId) {
        return res.status(401).json({ error: "Not authenticated" });
      }

      const user = await storage.getUser(req.session.userId);
      if (!user) {
        req.session.destroy(() => {});
        return res.status(401).json({ error: "User not found" });
      }

      const { password: _, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  app.post("/api/auth/logout", async (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ error: "Logout failed" });
      }
      res.clearCookie("connect.sid");
      res.json({ message: "Logged out successfully" });
    });
  });
  
  // ===== Dashboard Stats =====
  app.get("/api/dashboard/stats", requireAuth, async (req, res) => {
    try {
      const currentUser = (req as any).user;
      let stats;
      
      // Super admin sees all, others see only their company
      if (currentUser.role === "super_admin") {
        stats = await storage.getDashboardStats();
      } else if (currentUser.companyId) {
        stats = await storage.getDashboardStatsByCompany(currentUser.companyId);
      } else {
        stats = {
          totalCompanies: 0,
          totalEmployees: 0,
          totalUsers: 0,
          activeEmployees: 0,
          departmentDistribution: [],
          recentEmployees: []
        };
      }
      res.json(stats);
    } catch (error) {
      res.status(500).json({ error: "Failed to get dashboard stats" });
    }
  });

  // ===== Companies CRUD =====
  app.get("/api/companies", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      // Super admin sees all, company admin sees only their company
      if (user.role === "super_admin") {
        const companies = await storage.getAllCompanies();
        res.json(companies);
      } else if (user.companyId) {
        const company = await storage.getCompany(user.companyId);
        res.json(company ? [company] : []);
      } else {
        res.json([]);
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to get companies" });
    }
  });

  app.get("/api/companies/:id", requireAuth, async (req, res) => {
    try {
      const user = (req as any).user;
      const company = await storage.getCompany(req.params.id);
      if (!company) {
        return res.status(404).json({ error: "Company not found" });
      }
      // Non-super-admins can only view their own company
      if (user.role !== "super_admin" && user.companyId !== company.id) {
        return res.status(403).json({ error: "Access denied" });
      }
      res.json(company);
    } catch (error) {
      res.status(500).json({ error: "Failed to get company" });
    }
  });

  app.post("/api/companies", requireAuth, requireModuleAccess("companies"), async (req, res) => {
    try {
      const data = insertCompanySchema.parse(req.body);
      const company = await storage.createCompany(data);
      res.status(201).json(company);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create company" });
    }
  });

  app.patch("/api/companies/:id", requireAuth, requireModuleAccess("companies"), async (req, res) => {
    try {
      const data = insertCompanySchema.partial().parse(req.body);
      const company = await storage.updateCompany(req.params.id, data);
      if (!company) {
        return res.status(404).json({ error: "Company not found" });
      }
      res.json(company);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to update company" });
    }
  });

  app.delete("/api/companies/:id", requireAuth, requireModuleAccess("companies"), async (req, res) => {
    try {
      const success = await storage.deleteCompany(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Company not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete company" });
    }
  });

  // ===== Users CRUD =====
  app.get("/api/users", requireAuth, requireModuleAccess("users"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      let users = await storage.getAllUsers();
      
      // Super admin can see all users, others see only their company's users
      // Also hide super_admin users from non-super_admins
      if (currentUser.role !== "super_admin") {
        users = users.filter(u => u.role !== "super_admin" && u.companyId === currentUser.companyId);
      }
      
      // Don't send passwords to frontend
      const safeUsers = users.map(({ password, ...user }) => user);
      res.json(safeUsers);
    } catch (error) {
      res.status(500).json({ error: "Failed to get users" });
    }
  });

  app.get("/api/users/:id", requireAuth, requireModuleAccess("users"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const user = await storage.getUser(req.params.id);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      // Non-super-admin cannot view super_admin users
      if (currentUser.role !== "super_admin" && user.role === "super_admin") {
        return res.status(403).json({ error: "Access denied" });
      }
      // Non-super-admin can only view users from their company
      if (currentUser.role !== "super_admin" && user.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      const { password, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      res.status(500).json({ error: "Failed to get user" });
    }
  });

  app.post("/api/users", requireAuth, requireModuleAccess("users"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertUserSchema.parse(req.body);
      
      // Non-super-admin can only create users for their own company
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create users for other companies" });
      }
      
      // Check if username already exists
      const existingUsername = await storage.getUserByUsername(data.username);
      if (existingUsername) {
        return res.status(400).json({ error: "Username already exists" });
      }

      // Check if email already exists
      const existingEmail = await storage.getUserByEmail(data.email);
      if (existingEmail) {
        return res.status(400).json({ error: "Email already exists" });
      }

      const user = await storage.createUser(data);
      const { password, ...safeUser } = user;
      res.status(201).json(safeUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create user" });
    }
  });

  app.patch("/api/users/:id", requireAuth, requireModuleAccess("users"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertUserSchema.partial().parse(req.body);
      
      // Check existing user belongs to user's company
      const existingUser = await storage.getUser(req.params.id);
      if (!existingUser) {
        return res.status(404).json({ error: "User not found" });
      }
      // Non-super-admin cannot edit super_admin users
      if (currentUser.role !== "super_admin" && existingUser.role === "super_admin") {
        return res.status(403).json({ error: "Access denied" });
      }
      if (currentUser.role !== "super_admin" && existingUser.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      // If password is empty string, remove it from updates
      if (data.password === "") {
        delete data.password;
      }
      
      // Check if username already exists (if changing)
      if (data.username) {
        const userWithUsername = await storage.getUserByUsername(data.username);
        if (userWithUsername && userWithUsername.id !== req.params.id) {
          return res.status(400).json({ error: "Username already exists" });
        }
      }

      // Check if email already exists (if changing)
      if (data.email) {
        const userWithEmail = await storage.getUserByEmail(data.email);
        if (userWithEmail && userWithEmail.id !== req.params.id) {
          return res.status(400).json({ error: "Email already exists" });
        }
      }

      const user = await storage.updateUser(req.params.id, data);
      if (!user) {
        return res.status(404).json({ error: "User not found" });
      }
      const { password, ...safeUser } = user;
      res.json(safeUser);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to update user" });
    }
  });

  app.delete("/api/users/:id", requireAuth, requireModuleAccess("users"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      // Check user belongs to requester's company
      const userToDelete = await storage.getUser(req.params.id);
      if (!userToDelete) {
        return res.status(404).json({ error: "User not found" });
      }
      // Non-super-admin cannot delete super_admin users
      if (currentUser.role !== "super_admin" && userToDelete.role === "super_admin") {
        return res.status(403).json({ error: "Access denied" });
      }
      if (currentUser.role !== "super_admin" && userToDelete.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const success = await storage.deleteUser(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "User not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete user" });
    }
  });

  // ===== Employees CRUD =====
  app.get("/api/employees", requireAuth, requireModuleAccess("employees"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const { companyId } = req.query;
      let employees;
      
      // Super admin can see all, others see only their company
      if (currentUser.role === "super_admin") {
        if (companyId && typeof companyId === "string") {
          employees = await storage.getEmployeesByCompany(companyId);
        } else {
          employees = await storage.getAllEmployees();
        }
      } else if (currentUser.companyId) {
        employees = await storage.getEmployeesByCompany(currentUser.companyId);
      } else {
        employees = [];
      }
      res.json(employees);
    } catch (error) {
      res.status(500).json({ error: "Failed to get employees" });
    }
  });

  app.get("/api/employees/:id", requireAuth, requireModuleAccess("employees"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const employee = await storage.getEmployee(req.params.id);
      if (!employee) {
        return res.status(404).json({ error: "Employee not found" });
      }
      // Non-super-admin can only see employees from their company
      if (currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      res.json(employee);
    } catch (error) {
      res.status(500).json({ error: "Failed to get employee" });
    }
  });

  app.post("/api/employees", requireAuth, requireModuleAccess("employees"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertEmployeeSchema.parse(req.body);
      
      // Non-super-admin can only create employees for their own company
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create employees for other companies" });
      }
      
      // Verify company exists
      const company = await storage.getCompany(data.companyId);
      if (!company) {
        return res.status(400).json({ error: "Invalid company" });
      }

      const employee = await storage.createEmployee(data);
      res.status(201).json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create employee" });
    }
  });

  app.patch("/api/employees/:id", requireAuth, requireModuleAccess("employees"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertEmployeeSchema.partial().parse(req.body);
      
      // Check existing employee belongs to user's company
      const existingEmployee = await storage.getEmployee(req.params.id);
      if (!existingEmployee) {
        return res.status(404).json({ error: "Employee not found" });
      }
      if (currentUser.role !== "super_admin" && existingEmployee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      // If changing company, verify permission and company exists
      if (data.companyId) {
        if (currentUser.role !== "super_admin") {
          return res.status(403).json({ error: "Cannot transfer employees to other companies" });
        }
        const company = await storage.getCompany(data.companyId);
        if (!company) {
          return res.status(400).json({ error: "Invalid company" });
        }
      }

      const employee = await storage.updateEmployee(req.params.id, data);
      res.json(employee);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to update employee" });
    }
  });

  app.delete("/api/employees/:id", requireAuth, requireModuleAccess("employees"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      // Check employee belongs to user's company
      const employee = await storage.getEmployee(req.params.id);
      if (!employee) {
        return res.status(404).json({ error: "Employee not found" });
      }
      if (currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const success = await storage.deleteEmployee(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Employee not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete employee" });
    }
  });

  // ===== Attendance CRUD =====
  app.get("/api/attendance", requireAuth, requireModuleAccess("attendance"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const { companyId, date, employeeId } = req.query;
      let records;
      
      // Super admin can see all, others see only their company
      if (currentUser.role === "super_admin") {
        if (employeeId && typeof employeeId === "string") {
          records = await storage.getAttendanceByEmployee(employeeId, date as string | undefined);
        } else if (companyId && date && typeof companyId === "string" && typeof date === "string") {
          records = await storage.getAttendanceByDate(companyId, date);
        } else {
          records = await storage.getAllAttendance();
        }
      } else if (currentUser.companyId) {
        if (employeeId && typeof employeeId === "string") {
          // Validate employee belongs to user's company
          const employee = await storage.getEmployee(employeeId);
          if (!employee || employee.companyId !== currentUser.companyId) {
            return res.status(403).json({ error: "Access denied" });
          }
          records = await storage.getAttendanceByEmployee(employeeId, date as string | undefined);
        } else if (date && typeof date === "string") {
          records = await storage.getAttendanceByDate(currentUser.companyId, date);
        } else {
          records = await storage.getAttendanceByDate(currentUser.companyId, new Date().toISOString().split('T')[0]);
        }
      } else {
        records = [];
      }
      res.json(records);
    } catch (error) {
      res.status(500).json({ error: "Failed to get attendance" });
    }
  });

  app.post("/api/attendance", requireAuth, requireModuleAccess("attendance"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertAttendanceSchema.parse(req.body);
      
      // Verify employee belongs to user's company (non-super-admin)
      const employee = await storage.getEmployee(data.employeeId);
      if (!employee) {
        return res.status(400).json({ error: "Invalid employee" });
      }
      if (currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot record attendance for employees in other companies" });
      }
      
      const attendance = await storage.createAttendance(data);
      res.status(201).json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create attendance" });
    }
  });

  app.patch("/api/attendance/:id", requireAuth, requireModuleAccess("attendance"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertAttendanceSchema.partial().parse(req.body);
      
      // Check existing attendance record
      const existingRecord = await storage.getAttendance(req.params.id);
      if (!existingRecord) {
        return res.status(404).json({ error: "Attendance record not found" });
      }
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(existingRecord.employeeId);
      if (employee && currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const attendance = await storage.updateAttendance(req.params.id, data);
      res.json(attendance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to update attendance" });
    }
  });

  app.delete("/api/attendance/:id", requireAuth, requireModuleAccess("attendance"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      // Check existing attendance record
      const existingRecord = await storage.getAttendance(req.params.id);
      if (!existingRecord) {
        return res.status(404).json({ error: "Attendance record not found" });
      }
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(existingRecord.employeeId);
      if (employee && currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const success = await storage.deleteAttendance(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Attendance record not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete attendance" });
    }
  });

  // ===== Leave Types CRUD =====
  app.get("/api/leave-types", requireAuth, requireModuleAccess("leave"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const { companyId } = req.query;
      let leaveTypes;
      
      // Super admin can see all, others see only their company
      if (currentUser.role === "super_admin") {
        if (typeof companyId === "string") {
          leaveTypes = await storage.getLeaveTypesByCompany(companyId);
        } else {
          leaveTypes = await storage.getAllLeaveTypes();
        }
      } else if (currentUser.companyId) {
        leaveTypes = await storage.getLeaveTypesByCompany(currentUser.companyId);
      } else {
        leaveTypes = [];
      }
      res.json(leaveTypes);
    } catch (error) {
      res.status(500).json({ error: "Failed to get leave types" });
    }
  });

  app.post("/api/leave-types", requireAuth, requireRole("super_admin", "company_admin", "hr_admin"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertLeaveTypeSchema.parse(req.body);
      
      // Non-super-admin can only create leave types for their company
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create leave types for other companies" });
      }
      
      const leaveType = await storage.createLeaveType(data);
      res.status(201).json(leaveType);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create leave type" });
    }
  });

  app.patch("/api/leave-types/:id", requireAuth, requireRole("super_admin", "company_admin", "hr_admin"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertLeaveTypeSchema.partial().parse(req.body);
      
      // Check leave type exists and belongs to user's company
      const existingLeaveType = await storage.getLeaveType(req.params.id);
      if (!existingLeaveType) {
        return res.status(404).json({ error: "Leave type not found" });
      }
      if (currentUser.role !== "super_admin" && existingLeaveType.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const leaveType = await storage.updateLeaveType(req.params.id, data);
      res.json(leaveType);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to update leave type" });
    }
  });

  app.delete("/api/leave-types/:id", requireAuth, requireRole("super_admin", "company_admin", "hr_admin"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      // Check leave type exists and belongs to user's company
      const existingLeaveType = await storage.getLeaveType(req.params.id);
      if (!existingLeaveType) {
        return res.status(404).json({ error: "Leave type not found" });
      }
      if (currentUser.role !== "super_admin" && existingLeaveType.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const success = await storage.deleteLeaveType(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Leave type not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete leave type" });
    }
  });

  // ===== Leave Requests CRUD =====
  app.get("/api/leave-requests", requireAuth, requireModuleAccess("leave"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const { companyId, employeeId } = req.query;
      let requests;
      
      // Super admin can see all, others see only their company
      if (currentUser.role === "super_admin") {
        if (typeof employeeId === "string") {
          requests = await storage.getLeaveRequestsByEmployee(employeeId);
        } else if (typeof companyId === "string") {
          requests = await storage.getLeaveRequestsByCompany(companyId);
        } else {
          requests = await storage.getAllLeaveRequests();
        }
      } else if (currentUser.companyId) {
        if (typeof employeeId === "string") {
          // Validate employee belongs to user's company
          const employee = await storage.getEmployee(employeeId);
          if (!employee || employee.companyId !== currentUser.companyId) {
            return res.status(403).json({ error: "Access denied" });
          }
          requests = await storage.getLeaveRequestsByEmployee(employeeId);
        } else {
          requests = await storage.getLeaveRequestsByCompany(currentUser.companyId);
        }
      } else {
        requests = [];
      }
      res.json(requests);
    } catch (error) {
      res.status(500).json({ error: "Failed to get leave requests" });
    }
  });

  app.post("/api/leave-requests", requireAuth, requireModuleAccess("leave"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertLeaveRequestSchema.parse(req.body);
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(data.employeeId);
      if (!employee) {
        return res.status(400).json({ error: "Invalid employee" });
      }
      if (currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create leave requests for employees in other companies" });
      }
      
      const request = await storage.createLeaveRequest(data);
      res.status(201).json(request);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create leave request" });
    }
  });

  app.patch("/api/leave-requests/:id", requireAuth, requireRole("super_admin", "company_admin", "hr_admin", "manager"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = req.body;
      
      // Check leave request exists
      const existingRequest = await storage.getLeaveRequest(req.params.id);
      if (!existingRequest) {
        return res.status(404).json({ error: "Leave request not found" });
      }
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(existingRequest.employeeId);
      if (employee && currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const request = await storage.updateLeaveRequest(req.params.id, data);
      res.json(request);
    } catch (error) {
      res.status(500).json({ error: "Failed to update leave request" });
    }
  });

  app.delete("/api/leave-requests/:id", requireAuth, requireRole("super_admin", "company_admin", "hr_admin"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      // Check leave request exists
      const existingRequest = await storage.getLeaveRequest(req.params.id);
      if (!existingRequest) {
        return res.status(404).json({ error: "Leave request not found" });
      }
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(existingRequest.employeeId);
      if (employee && currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const success = await storage.deleteLeaveRequest(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Leave request not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete leave request" });
    }
  });

  // ===== Salary Structures CRUD =====
  app.get("/api/salary-structures", requireAuth, requireModuleAccess("payroll"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const { employeeId } = req.query;
      
      if (typeof employeeId === "string") {
        // Validate employee belongs to user's company (non-super-admin)
        if (currentUser.role !== "super_admin") {
          const employee = await storage.getEmployee(employeeId);
          if (!employee || employee.companyId !== currentUser.companyId) {
            return res.status(403).json({ error: "Access denied" });
          }
        }
        const structure = await storage.getSalaryStructureByEmployee(employeeId);
        res.json(structure ? [structure] : []);
      } else {
        // Super admin can see all, others see only their company's structures
        if (currentUser.role === "super_admin") {
          const structures = await storage.getAllSalaryStructures();
          res.json(structures);
        } else if (currentUser.companyId) {
          // Filter by company - get employees from user's company, then their structures
          const employees = await storage.getEmployeesByCompany(currentUser.companyId);
          const employeeIds = new Set(employees.map(e => e.id));
          const allStructures = await storage.getAllSalaryStructures();
          const companyStructures = allStructures.filter(s => employeeIds.has(s.employeeId));
          res.json(companyStructures);
        } else {
          res.json([]);
        }
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to get salary structures" });
    }
  });

  app.post("/api/salary-structures", requireAuth, requireModuleAccess("payroll"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertSalaryStructureSchema.parse(req.body);
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(data.employeeId);
      if (!employee) {
        return res.status(400).json({ error: "Invalid employee" });
      }
      if (currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create salary structures for employees in other companies" });
      }
      
      const structure = await storage.createSalaryStructure(data);
      res.status(201).json(structure);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create salary structure" });
    }
  });

  app.patch("/api/salary-structures/:id", requireAuth, requireModuleAccess("payroll"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertSalaryStructureSchema.partial().parse(req.body);
      
      // Check structure exists
      const existingStructure = await storage.getSalaryStructure(req.params.id);
      if (!existingStructure) {
        return res.status(404).json({ error: "Salary structure not found" });
      }
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(existingStructure.employeeId);
      if (employee && currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const structure = await storage.updateSalaryStructure(req.params.id, data);
      res.json(structure);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to update salary structure" });
    }
  });

  app.delete("/api/salary-structures/:id", requireAuth, requireModuleAccess("payroll"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      // Check structure exists
      const existingStructure = await storage.getSalaryStructure(req.params.id);
      if (!existingStructure) {
        return res.status(404).json({ error: "Salary structure not found" });
      }
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(existingStructure.employeeId);
      if (employee && currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const success = await storage.deleteSalaryStructure(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Salary structure not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete salary structure" });
    }
  });

  // ===== Payroll CRUD =====
  app.get("/api/payroll", requireAuth, requireModuleAccess("payroll"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const { companyId, month, year, employeeId } = req.query;
      let records;
      
      // Super admin can see all, others see only their company
      if (currentUser.role === "super_admin") {
        if (typeof employeeId === "string") {
          records = await storage.getPayrollByEmployee(employeeId);
        } else if (typeof companyId === "string" && typeof month === "string" && typeof year === "string") {
          records = await storage.getPayrollByMonth(companyId, month, parseInt(year));
        } else {
          records = await storage.getAllPayroll();
        }
      } else if (currentUser.companyId) {
        if (typeof employeeId === "string") {
          // Validate employee belongs to user's company
          const employee = await storage.getEmployee(employeeId);
          if (!employee || employee.companyId !== currentUser.companyId) {
            return res.status(403).json({ error: "Access denied" });
          }
          records = await storage.getPayrollByEmployee(employeeId);
        } else if (typeof month === "string" && typeof year === "string") {
          records = await storage.getPayrollByMonth(currentUser.companyId, month, parseInt(year));
        } else {
          records = await storage.getPayrollByMonth(currentUser.companyId, new Date().toLocaleString('default', { month: 'long' }), new Date().getFullYear());
        }
      } else {
        records = [];
      }
      res.json(records);
    } catch (error) {
      res.status(500).json({ error: "Failed to get payroll" });
    }
  });

  app.post("/api/payroll", requireAuth, requireModuleAccess("payroll"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertPayrollSchema.parse(req.body);
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(data.employeeId);
      if (!employee) {
        return res.status(400).json({ error: "Invalid employee" });
      }
      if (currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create payroll for employees in other companies" });
      }
      
      const payroll = await storage.createPayroll(data);
      res.status(201).json(payroll);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create payroll" });
    }
  });

  app.patch("/api/payroll/:id", requireAuth, requireModuleAccess("payroll"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertPayrollSchema.partial().parse(req.body);
      
      // Check payroll exists
      const existingPayroll = await storage.getPayroll(req.params.id);
      if (!existingPayroll) {
        return res.status(404).json({ error: "Payroll record not found" });
      }
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(existingPayroll.employeeId);
      if (employee && currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const payroll = await storage.updatePayroll(req.params.id, data);
      res.json(payroll);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to update payroll" });
    }
  });

  app.delete("/api/payroll/:id", requireAuth, requireModuleAccess("payroll"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      // Check payroll exists
      const existingPayroll = await storage.getPayroll(req.params.id);
      if (!existingPayroll) {
        return res.status(404).json({ error: "Payroll record not found" });
      }
      
      // Verify employee belongs to user's company
      const employee = await storage.getEmployee(existingPayroll.employeeId);
      if (employee && currentUser.role !== "super_admin" && employee.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const success = await storage.deletePayroll(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Payroll record not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete payroll" });
    }
  });

  // ===== Settings CRUD =====
  app.get("/api/settings", requireAuth, requireModuleAccess("settings"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const { companyId, category } = req.query;
      let settings;
      
      // Super admin can see all, others see only their company or system settings
      const effectiveCompanyId = currentUser.role === "super_admin" 
        ? (typeof companyId === "string" ? companyId : null)
        : currentUser.companyId || null;
      
      if (typeof category === "string") {
        settings = await storage.getSettingsByCategory(effectiveCompanyId, category);
      } else {
        if (currentUser.role === "super_admin") {
          settings = await storage.getAllSettings();
        } else {
          // For non-super-admin, get only their company's settings and system settings
          settings = await storage.getAllSettings();
          settings = settings.filter(s => s.companyId === currentUser.companyId || s.companyId === null);
        }
      }
      res.json(settings);
    } catch (error) {
      res.status(500).json({ error: "Failed to get settings" });
    }
  });

  app.post("/api/settings", requireAuth, requireModuleAccess("settings"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertSettingSchema.parse(req.body);
      
      // Non-super-admin can only create settings for their own company (not system/global settings)
      if (currentUser.role !== "super_admin") {
        if (data.companyId === null || data.companyId === undefined) {
          return res.status(403).json({ error: "Cannot create system-level settings" });
        }
        if (data.companyId !== currentUser.companyId) {
          return res.status(403).json({ error: "Cannot create settings for other companies" });
        }
      }
      
      const setting = await storage.createSetting(data);
      res.status(201).json(setting);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to create setting" });
    }
  });

  app.patch("/api/settings/:id", requireAuth, requireModuleAccess("settings"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertSettingSchema.partial().parse(req.body);
      
      // Check setting exists and belongs to user's company
      const existingSetting = await storage.getSetting(req.params.id);
      if (!existingSetting) {
        return res.status(404).json({ error: "Setting not found" });
      }
      
      // Non-super-admin cannot modify system-level settings or settings from other companies
      if (currentUser.role !== "super_admin") {
        if (existingSetting.companyId === null) {
          return res.status(403).json({ error: "Cannot modify system-level settings" });
        }
        if (existingSetting.companyId !== currentUser.companyId) {
          return res.status(403).json({ error: "Access denied" });
        }
        // Prevent changing companyId on update
        if (data.companyId !== undefined && data.companyId !== existingSetting.companyId) {
          return res.status(403).json({ error: "Cannot change setting's company" });
        }
      }
      
      const setting = await storage.updateSetting(req.params.id, data);
      res.json(setting);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors[0].message });
      }
      res.status(500).json({ error: "Failed to update setting" });
    }
  });

  app.delete("/api/settings/:id", requireAuth, requireModuleAccess("settings"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      // Check setting exists and belongs to user's company
      const existingSetting = await storage.getSetting(req.params.id);
      if (!existingSetting) {
        return res.status(404).json({ error: "Setting not found" });
      }
      
      // Non-super-admin cannot delete system-level settings or settings from other companies
      if (currentUser.role !== "super_admin") {
        if (existingSetting.companyId === null) {
          return res.status(403).json({ error: "Cannot delete system-level settings" });
        }
        if (existingSetting.companyId !== currentUser.companyId) {
          return res.status(403).json({ error: "Access denied" });
        }
      }
      
      const success = await storage.deleteSetting(req.params.id);
      if (!success) {
        return res.status(404).json({ error: "Setting not found" });
      }
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete setting" });
    }
  });

  // ===== MASTER DATA ROUTES =====

  // Master Departments
  app.get("/api/master-departments", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const companyId = req.query.companyId as string | undefined;
      
      if (currentUser.role === "super_admin" && companyId) {
        const depts = await storage.getMasterDepartmentsByCompany(companyId);
        return res.json(depts);
      }
      
      if (!currentUser.companyId) {
        return res.json([]);
      }
      
      const depts = await storage.getMasterDepartmentsByCompany(currentUser.companyId);
      res.json(depts);
    } catch (error) {
      res.status(500).json({ error: "Failed to get departments" });
    }
  });

  app.post("/api/master-departments", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertMasterDepartmentSchema.parse(req.body);
      
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create department for other companies" });
      }
      
      const dept = await storage.createMasterDepartment(data);
      res.status(201).json(dept);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create department" });
    }
  });

  app.patch("/api/master-departments/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertMasterDepartmentSchema.partial().parse(req.body);
      
      const existing = await storage.getMasterDepartment(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Department not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const updated = await storage.updateMasterDepartment(req.params.id, data);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update department" });
    }
  });

  app.delete("/api/master-departments/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      const existing = await storage.getMasterDepartment(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Department not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      await storage.deleteMasterDepartment(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete department" });
    }
  });

  // Master Designations
  app.get("/api/master-designations", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const companyId = req.query.companyId as string | undefined;
      
      if (currentUser.role === "super_admin" && companyId) {
        const desgs = await storage.getMasterDesignationsByCompany(companyId);
        return res.json(desgs);
      }
      
      if (!currentUser.companyId) {
        return res.json([]);
      }
      
      const desgs = await storage.getMasterDesignationsByCompany(currentUser.companyId);
      res.json(desgs);
    } catch (error) {
      res.status(500).json({ error: "Failed to get designations" });
    }
  });

  app.post("/api/master-designations", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertMasterDesignationSchema.parse(req.body);
      
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create designation for other companies" });
      }
      
      const desg = await storage.createMasterDesignation(data);
      res.status(201).json(desg);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create designation" });
    }
  });

  app.patch("/api/master-designations/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertMasterDesignationSchema.partial().parse(req.body);
      
      const existing = await storage.getMasterDesignation(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Designation not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const updated = await storage.updateMasterDesignation(req.params.id, data);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update designation" });
    }
  });

  app.delete("/api/master-designations/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      const existing = await storage.getMasterDesignation(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Designation not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      await storage.deleteMasterDesignation(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete designation" });
    }
  });

  // Master Locations
  app.get("/api/master-locations", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const companyId = req.query.companyId as string | undefined;
      
      if (currentUser.role === "super_admin" && companyId) {
        const locs = await storage.getMasterLocationsByCompany(companyId);
        return res.json(locs);
      }
      
      if (!currentUser.companyId) {
        return res.json([]);
      }
      
      const locs = await storage.getMasterLocationsByCompany(currentUser.companyId);
      res.json(locs);
    } catch (error) {
      res.status(500).json({ error: "Failed to get locations" });
    }
  });

  app.post("/api/master-locations", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertMasterLocationSchema.parse(req.body);
      
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create location for other companies" });
      }
      
      const loc = await storage.createMasterLocation(data);
      res.status(201).json(loc);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create location" });
    }
  });

  app.patch("/api/master-locations/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertMasterLocationSchema.partial().parse(req.body);
      
      const existing = await storage.getMasterLocation(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Location not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const updated = await storage.updateMasterLocation(req.params.id, data);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update location" });
    }
  });

  app.delete("/api/master-locations/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      const existing = await storage.getMasterLocation(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Location not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      await storage.deleteMasterLocation(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete location" });
    }
  });

  // Earning Heads
  app.get("/api/earning-heads", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const companyId = req.query.companyId as string | undefined;
      
      if (currentUser.role === "super_admin" && companyId) {
        const heads = await storage.getEarningHeadsByCompany(companyId);
        return res.json(heads);
      }
      
      if (!currentUser.companyId) {
        return res.json([]);
      }
      
      const heads = await storage.getEarningHeadsByCompany(currentUser.companyId);
      res.json(heads);
    } catch (error) {
      res.status(500).json({ error: "Failed to get earning heads" });
    }
  });

  app.post("/api/earning-heads", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertEarningHeadSchema.parse(req.body);
      
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create earning head for other companies" });
      }
      
      const head = await storage.createEarningHead(data);
      res.status(201).json(head);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create earning head" });
    }
  });

  app.patch("/api/earning-heads/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertEarningHeadSchema.partial().parse(req.body);
      
      const existing = await storage.getEarningHead(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Earning head not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const updated = await storage.updateEarningHead(req.params.id, data);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update earning head" });
    }
  });

  app.delete("/api/earning-heads/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      const existing = await storage.getEarningHead(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Earning head not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      await storage.deleteEarningHead(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete earning head" });
    }
  });

  // Deduction Heads
  app.get("/api/deduction-heads", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const companyId = req.query.companyId as string | undefined;
      
      if (currentUser.role === "super_admin" && companyId) {
        const heads = await storage.getDeductionHeadsByCompany(companyId);
        return res.json(heads);
      }
      
      if (!currentUser.companyId) {
        return res.json([]);
      }
      
      const heads = await storage.getDeductionHeadsByCompany(currentUser.companyId);
      res.json(heads);
    } catch (error) {
      res.status(500).json({ error: "Failed to get deduction heads" });
    }
  });

  app.post("/api/deduction-heads", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertDeductionHeadSchema.parse(req.body);
      
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create deduction head for other companies" });
      }
      
      const head = await storage.createDeductionHead(data);
      res.status(201).json(head);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create deduction head" });
    }
  });

  app.patch("/api/deduction-heads/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertDeductionHeadSchema.partial().parse(req.body);
      
      const existing = await storage.getDeductionHead(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Deduction head not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const updated = await storage.updateDeductionHead(req.params.id, data);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update deduction head" });
    }
  });

  app.delete("/api/deduction-heads/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      
      const existing = await storage.getDeductionHead(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Deduction head not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      await storage.deleteDeductionHead(req.params.id);
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete deduction head" });
    }
  });

  // Statutory Settings
  app.get("/api/statutory-settings", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const companyId = req.query.companyId as string | undefined;
      
      if (currentUser.role === "super_admin" && companyId) {
        const settings = await storage.getStatutorySettingsByCompany(companyId);
        return res.json(settings || null);
      }
      
      if (!currentUser.companyId) {
        return res.json(null);
      }
      
      const settings = await storage.getStatutorySettingsByCompany(currentUser.companyId);
      res.json(settings || null);
    } catch (error) {
      res.status(500).json({ error: "Failed to get statutory settings" });
    }
  });

  app.post("/api/statutory-settings", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertStatutorySettingsSchema.parse(req.body);
      
      if (currentUser.role !== "super_admin" && data.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Cannot create statutory settings for other companies" });
      }
      
      // Check if settings already exist for this company
      const existing = await storage.getStatutorySettingsByCompany(data.companyId);
      if (existing) {
        // Update existing instead of creating new
        const updated = await storage.updateStatutorySettings(existing.id, data);
        return res.json(updated);
      }
      
      const settings = await storage.createStatutorySettings(data);
      res.status(201).json(settings);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: error.errors });
      }
      res.status(500).json({ error: "Failed to create statutory settings" });
    }
  });

  app.patch("/api/statutory-settings/:id", requireAuth, requireModuleAccess("masters"), async (req, res) => {
    try {
      const currentUser = (req as any).user;
      const data = insertStatutorySettingsSchema.partial().parse(req.body);
      
      const existing = await storage.getStatutorySettings(req.params.id);
      if (!existing) {
        return res.status(404).json({ error: "Statutory settings not found" });
      }
      if (currentUser.role !== "super_admin" && existing.companyId !== currentUser.companyId) {
        return res.status(403).json({ error: "Access denied" });
      }
      
      const updated = await storage.updateStatutorySettings(req.params.id, data);
      res.json(updated);
    } catch (error) {
      res.status(500).json({ error: "Failed to update statutory settings" });
    }
  });

  return httpServer;
}
