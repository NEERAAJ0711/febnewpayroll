import { 
  Building2, 
  Users, 
  UserCircle, 
  LayoutDashboard,
  Calendar,
  Clock,
  FileText,
  Settings,
  ChevronUp,
  LogOut
} from "lucide-react";
import { useLocation } from "wouter";
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarGroup,
  SidebarGroupContent,
  SidebarGroupLabel,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { useAuth } from "@/lib/auth";
import { useToast } from "@/hooks/use-toast";
import type { User } from "@shared/schema";

type UserRole = User["role"];

const MODULE_ACCESS: Record<string, UserRole[]> = {
  dashboard: ["super_admin", "company_admin", "hr_admin", "recruiter", "manager", "employee"],
  companies: ["super_admin"],
  users: ["super_admin", "company_admin"],
  employees: ["super_admin", "company_admin", "hr_admin", "manager"],
  attendance: ["super_admin", "company_admin", "hr_admin", "manager", "employee"],
  leave: ["super_admin", "company_admin", "hr_admin", "manager", "employee"],
  payroll: ["super_admin", "company_admin", "hr_admin"],
  settings: ["super_admin", "company_admin"],
};

const hasModuleAccess = (module: string, userRole: UserRole | undefined): boolean => {
  if (!userRole) return false;
  const allowedRoles = MODULE_ACCESS[module];
  return allowedRoles ? allowedRoles.includes(userRole) : false;
};

const mainMenuItems = [
  {
    title: "Dashboard",
    url: "/",
    icon: LayoutDashboard,
    module: "dashboard",
  },
  {
    title: "Companies",
    url: "/companies",
    icon: Building2,
    module: "companies",
  },
  {
    title: "Employees",
    url: "/employees",
    icon: Users,
    module: "employees",
  },
  {
    title: "Users",
    url: "/users",
    icon: UserCircle,
    module: "users",
  },
];

const hrModulesItems = [
  {
    title: "Attendance",
    url: "/attendance",
    icon: Clock,
    module: "attendance",
  },
  {
    title: "Leave Management",
    url: "/leave",
    icon: Calendar,
    module: "leave",
  },
  {
    title: "Payroll",
    url: "/payroll",
    icon: FileText,
    module: "payroll",
  },
  {
    title: "Settings",
    url: "/settings",
    icon: Settings,
    module: "settings",
  },
];

export function AppSidebar() {
  const [location, setLocation] = useLocation();
  const { user, logout } = useAuth();
  const { toast } = useToast();

  const handleNavigation = (url: string) => {
    setLocation(url);
  };

  const handleLogout = async () => {
    try {
      await logout();
      toast({
        title: "Signed out",
        description: "You have been successfully logged out.",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to sign out. Please try again.",
        variant: "destructive",
      });
    }
  };

  const userInitials = user 
    ? `${user.firstName?.[0] || ''}${user.lastName?.[0] || ''}`.toUpperCase() || user.username.substring(0, 2).toUpperCase()
    : 'U';
  
  const displayName = user 
    ? `${user.firstName || ''} ${user.lastName || ''}`.trim() || user.username
    : 'User';

  const filteredMainMenu = mainMenuItems.filter(item => hasModuleAccess(item.module, user?.role));
  const filteredHrModules = hrModulesItems.filter(item => hasModuleAccess(item.module, user?.role));

  return (
    <Sidebar>
      <SidebarHeader className="border-b border-sidebar-border px-4 py-4">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-md bg-sidebar-primary">
            <Building2 className="h-5 w-5 text-sidebar-primary-foreground" />
          </div>
          <div className="flex flex-col">
            <span className="text-base font-semibold text-sidebar-foreground">HRMS Pro</span>
            <span className="text-xs text-sidebar-foreground/60">Multi-Company</span>
          </div>
        </div>
      </SidebarHeader>
      
      <SidebarContent>
        {filteredMainMenu.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-sidebar-foreground/50 text-xs uppercase tracking-wider">
              Main Menu
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {filteredMainMenu.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      isActive={location === item.url}
                      onClick={() => handleNavigation(item.url)}
                      data-testid={`nav-${item.title.toLowerCase()}`}
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}

        {filteredHrModules.length > 0 && (
          <SidebarGroup>
            <SidebarGroupLabel className="text-sidebar-foreground/50 text-xs uppercase tracking-wider">
              HR Modules
            </SidebarGroupLabel>
            <SidebarGroupContent>
              <SidebarMenu>
                {filteredHrModules.map((item) => (
                  <SidebarMenuItem key={item.title}>
                    <SidebarMenuButton 
                      isActive={location === item.url}
                      onClick={() => handleNavigation(item.url)}
                      data-testid={`nav-${item.title.toLowerCase().replace(' ', '-')}`}
                    >
                      <item.icon className="h-4 w-4" />
                      <span>{item.title}</span>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
              </SidebarMenu>
            </SidebarGroupContent>
          </SidebarGroup>
        )}
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border">
        <div className="p-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button 
                className="flex items-center gap-2 w-full p-2 rounded-md hover-elevate text-sidebar-foreground"
                data-testid="button-user-menu"
              >
                <Avatar className="h-8 w-8">
                  <AvatarFallback className="bg-sidebar-primary text-sidebar-primary-foreground text-xs">
                    {userInitials}
                  </AvatarFallback>
                </Avatar>
                <div className="flex flex-col flex-1 text-left min-w-0">
                  <span className="text-sm font-medium truncate">{displayName}</span>
                  <span className="text-xs text-sidebar-foreground/60 truncate">{user?.email}</span>
                </div>
                <ChevronUp className="h-4 w-4 flex-shrink-0" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent
              side="top"
              className="w-56"
            >
              <DropdownMenuItem 
                onClick={handleLogout}
                data-testid="menu-item-logout"
              >
                <LogOut className="h-4 w-4 mr-2" />
                <span>Sign out</span>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </SidebarFooter>
    </Sidebar>
  );
}
