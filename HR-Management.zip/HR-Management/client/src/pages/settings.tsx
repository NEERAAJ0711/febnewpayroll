import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Settings, Building2, Calendar, Clock, Bell, Shield, Globe, Save, Users, Briefcase, MapPin, DollarSign, Percent, Plus, Pencil, Trash2, FileText } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Separator } from "@/components/ui/separator";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useAuth } from "@/lib/auth";
import type { Company, Setting, MasterDepartment, MasterDesignation, MasterLocation, EarningHead, DeductionHead, StatutorySettings } from "@shared/schema";

interface SettingFormData {
  workingHoursStart: string;
  workingHoursEnd: string;
  weekStartDay: string;
  dateFormat: string;
  timeFormat: string;
  timezone: string;
  currency: string;
  fiscalYearStart: string;
  enableEmailNotifications: boolean;
  enableLeaveApprovalNotifications: boolean;
  enablePayrollNotifications: boolean;
  enableAttendanceReminders: boolean;
  passwordMinLength: string;
  sessionTimeout: string;
  twoFactorEnabled: boolean;
  ipRestriction: boolean;
}

export default function SettingsPage() {
  const { toast } = useToast();
  const { user } = useAuth();
  const [selectedCompany, setSelectedCompany] = useState<string>("__global__");
  const [activeTab, setActiveTab] = useState("general");
  
  const [formData, setFormData] = useState<SettingFormData>({
    workingHoursStart: "09:00",
    workingHoursEnd: "18:00",
    weekStartDay: "monday",
    dateFormat: "DD/MM/YYYY",
    timeFormat: "24h",
    timezone: "Asia/Kolkata",
    currency: "INR",
    fiscalYearStart: "04",
    enableEmailNotifications: true,
    enableLeaveApprovalNotifications: true,
    enablePayrollNotifications: true,
    enableAttendanceReminders: false,
    passwordMinLength: "8",
    sessionTimeout: "30",
    twoFactorEnabled: false,
    ipRestriction: false,
  });

  const { data: companies = [] } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const { data: settings = [] } = useQuery<Setting[]>({
    queryKey: ["/api/settings"],
  });

  const companyIdForQueries = user?.role === "super_admin" 
    ? (selectedCompany === "__global__" ? undefined : selectedCompany)
    : (user?.companyId ?? undefined);

  const saveMutation = useMutation({
    mutationFn: async (data: SettingFormData) => {
      // Use companyIdForQueries to ensure proper company context
      // For non-super_admin users, this will be their companyId
      // For super_admin, this will be the selected company or undefined for global
      const settingsToSave = Object.entries(data).map(([key, value]) => ({
        companyId: companyIdForQueries || null,
        key,
        value: String(value),
        category: getCategoryForKey(key),
      }));
      
      for (const setting of settingsToSave) {
        await apiRequest("POST", "/api/settings", setting);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/settings"] });
      toast({
        title: "Settings Saved",
        description: "Your settings have been saved successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getCategoryForKey = (key: string): string => {
    if (key.startsWith("working") || key.includes("Week") || key.includes("fiscal")) return "general";
    if (key.includes("Format") || key.includes("timezone") || key.includes("currency")) return "localization";
    if (key.includes("Notification") || key.includes("Reminder")) return "notifications";
    if (key.includes("password") || key.includes("session") || key.includes("Factor") || key.includes("Restriction")) return "security";
    return "general";
  };

  const handleInputChange = (key: keyof SettingFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="p-6" data-testid="settings-page">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Settings</h1>
          <p className="text-muted-foreground">Configure system preferences and company settings</p>
        </div>
        <div className="flex items-center gap-4">
          {user?.role === "super_admin" && (
            <Select value={selectedCompany} onValueChange={setSelectedCompany}>
              <SelectTrigger className="w-48" data-testid="select-settings-company">
                <SelectValue placeholder="Global Settings" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="__global__">Global Settings</SelectItem>
                {companies.map((company) => (
                  <SelectItem key={company.id} value={company.id}>{company.companyName}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
          {(activeTab === "general" || activeTab === "localization" || activeTab === "notifications" || activeTab === "security") && (
            <Button onClick={() => saveMutation.mutate(formData)} disabled={saveMutation.isPending} data-testid="button-save-settings">
              <Save className="h-4 w-4 mr-2" />
              {saveMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          )}
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-6">
          <TabsTrigger value="general" data-testid="tab-general">
            <Building2 className="h-4 w-4 mr-2" />
            General
          </TabsTrigger>
          <TabsTrigger value="localization" data-testid="tab-localization">
            <Globe className="h-4 w-4 mr-2" />
            Localization
          </TabsTrigger>
          <TabsTrigger value="masters" data-testid="tab-masters">
            <Briefcase className="h-4 w-4 mr-2" />
            Masters
          </TabsTrigger>
          <TabsTrigger value="statutory" data-testid="tab-statutory">
            <Percent className="h-4 w-4 mr-2" />
            Statutory
          </TabsTrigger>
          <TabsTrigger value="notifications" data-testid="tab-notifications">
            <Bell className="h-4 w-4 mr-2" />
            Notifications
          </TabsTrigger>
          <TabsTrigger value="security" data-testid="tab-security">
            <Shield className="h-4 w-4 mr-2" />
            Security
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general">
          <GeneralSettings formData={formData} handleInputChange={handleInputChange} />
        </TabsContent>

        <TabsContent value="localization">
          <LocalizationSettings formData={formData} handleInputChange={handleInputChange} />
        </TabsContent>

        <TabsContent value="masters">
          <MastersSettings companyId={companyIdForQueries} selectedCompany={selectedCompany} userRole={user?.role} />
        </TabsContent>

        <TabsContent value="statutory">
          <StatutorySettingsTab companyId={companyIdForQueries} selectedCompany={selectedCompany} />
        </TabsContent>

        <TabsContent value="notifications">
          <NotificationSettings formData={formData} handleInputChange={handleInputChange} />
        </TabsContent>

        <TabsContent value="security">
          <SecuritySettings formData={formData} handleInputChange={handleInputChange} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function GeneralSettings({ formData, handleInputChange }: { formData: SettingFormData; handleInputChange: (key: keyof SettingFormData, value: string | boolean) => void }) {
  return (
    <div className="grid gap-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="h-5 w-5" />
            Working Hours
          </CardTitle>
          <CardDescription>Configure standard working hours for the organization</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="workingHoursStart">Start Time</Label>
              <Input
                id="workingHoursStart"
                type="time"
                value={formData.workingHoursStart}
                onChange={(e) => handleInputChange("workingHoursStart", e.target.value)}
                data-testid="input-working-start"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="workingHoursEnd">End Time</Label>
              <Input
                id="workingHoursEnd"
                type="time"
                value={formData.workingHoursEnd}
                onChange={(e) => handleInputChange("workingHoursEnd", e.target.value)}
                data-testid="input-working-end"
              />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="weekStartDay">Week Starts On</Label>
            <Select value={formData.weekStartDay} onValueChange={(v) => handleInputChange("weekStartDay", v)}>
              <SelectTrigger data-testid="select-week-start">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sunday">Sunday</SelectItem>
                <SelectItem value="monday">Monday</SelectItem>
                <SelectItem value="saturday">Saturday</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Fiscal Year
          </CardTitle>
          <CardDescription>Set the fiscal year start month</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <Label htmlFor="fiscalYearStart">Fiscal Year Starts</Label>
            <Select value={formData.fiscalYearStart} onValueChange={(v) => handleInputChange("fiscalYearStart", v)}>
              <SelectTrigger data-testid="select-fiscal-year">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="01">January</SelectItem>
                <SelectItem value="04">April (India)</SelectItem>
                <SelectItem value="07">July</SelectItem>
                <SelectItem value="10">October</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function LocalizationSettings({ formData, handleInputChange }: { formData: SettingFormData; handleInputChange: (key: keyof SettingFormData, value: string | boolean) => void }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Localization Settings</CardTitle>
        <CardDescription>Configure date, time, and currency formats</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="dateFormat">Date Format</Label>
            <Select value={formData.dateFormat} onValueChange={(v) => handleInputChange("dateFormat", v)}>
              <SelectTrigger data-testid="select-date-format">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="timeFormat">Time Format</Label>
            <Select value={formData.timeFormat} onValueChange={(v) => handleInputChange("timeFormat", v)}>
              <SelectTrigger data-testid="select-time-format">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="12h">12-hour</SelectItem>
                <SelectItem value="24h">24-hour</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Separator />
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="timezone">Timezone</Label>
            <Select value={formData.timezone} onValueChange={(v) => handleInputChange("timezone", v)}>
              <SelectTrigger data-testid="select-timezone">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="Asia/Kolkata">India (IST)</SelectItem>
                <SelectItem value="America/New_York">US Eastern</SelectItem>
                <SelectItem value="America/Los_Angeles">US Pacific</SelectItem>
                <SelectItem value="Europe/London">UK (GMT)</SelectItem>
                <SelectItem value="Asia/Singapore">Singapore</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="currency">Currency</Label>
            <Select value={formData.currency} onValueChange={(v) => handleInputChange("currency", v)}>
              <SelectTrigger data-testid="select-currency">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="INR">Indian Rupee (INR)</SelectItem>
                <SelectItem value="USD">US Dollar (USD)</SelectItem>
                <SelectItem value="EUR">Euro (EUR)</SelectItem>
                <SelectItem value="GBP">British Pound (GBP)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function NotificationSettings({ formData, handleInputChange }: { formData: SettingFormData; handleInputChange: (key: keyof SettingFormData, value: string | boolean) => void }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Notification Preferences</CardTitle>
        <CardDescription>Configure email and system notifications</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label>Email Notifications</Label>
            <p className="text-sm text-muted-foreground">Receive important updates via email</p>
          </div>
          <Switch
            checked={formData.enableEmailNotifications}
            onCheckedChange={(v) => handleInputChange("enableEmailNotifications", v)}
            data-testid="switch-email-notifications"
          />
        </div>
        <Separator />
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label>Leave Approval Notifications</Label>
            <p className="text-sm text-muted-foreground">Get notified when leave requests need approval</p>
          </div>
          <Switch
            checked={formData.enableLeaveApprovalNotifications}
            onCheckedChange={(v) => handleInputChange("enableLeaveApprovalNotifications", v)}
            data-testid="switch-leave-notifications"
          />
        </div>
        <Separator />
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label>Payroll Notifications</Label>
            <p className="text-sm text-muted-foreground">Get notified about payroll processing updates</p>
          </div>
          <Switch
            checked={formData.enablePayrollNotifications}
            onCheckedChange={(v) => handleInputChange("enablePayrollNotifications", v)}
            data-testid="switch-payroll-notifications"
          />
        </div>
        <Separator />
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label>Attendance Reminders</Label>
            <p className="text-sm text-muted-foreground">Send daily reminders for marking attendance</p>
          </div>
          <Switch
            checked={formData.enableAttendanceReminders}
            onCheckedChange={(v) => handleInputChange("enableAttendanceReminders", v)}
            data-testid="switch-attendance-reminders"
          />
        </div>
      </CardContent>
    </Card>
  );
}

function SecuritySettings({ formData, handleInputChange }: { formData: SettingFormData; handleInputChange: (key: keyof SettingFormData, value: string | boolean) => void }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Security Settings</CardTitle>
        <CardDescription>Configure security and access controls</CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="passwordMinLength">Minimum Password Length</Label>
            <Select value={formData.passwordMinLength} onValueChange={(v) => handleInputChange("passwordMinLength", v)}>
              <SelectTrigger data-testid="select-password-length">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6">6 characters</SelectItem>
                <SelectItem value="8">8 characters</SelectItem>
                <SelectItem value="10">10 characters</SelectItem>
                <SelectItem value="12">12 characters</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-2">
            <Label htmlFor="sessionTimeout">Session Timeout (minutes)</Label>
            <Select value={formData.sessionTimeout} onValueChange={(v) => handleInputChange("sessionTimeout", v)}>
              <SelectTrigger data-testid="select-session-timeout">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="15">15 minutes</SelectItem>
                <SelectItem value="30">30 minutes</SelectItem>
                <SelectItem value="60">1 hour</SelectItem>
                <SelectItem value="120">2 hours</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <Separator />
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label>Two-Factor Authentication</Label>
            <p className="text-sm text-muted-foreground">Require 2FA for all users</p>
          </div>
          <Switch
            checked={formData.twoFactorEnabled}
            onCheckedChange={(v) => handleInputChange("twoFactorEnabled", v)}
            data-testid="switch-2fa"
          />
        </div>
        <Separator />
        <div className="flex items-center justify-between">
          <div className="space-y-0.5">
            <Label>IP Restriction</Label>
            <p className="text-sm text-muted-foreground">Restrict access to specific IP addresses</p>
          </div>
          <Switch
            checked={formData.ipRestriction}
            onCheckedChange={(v) => handleInputChange("ipRestriction", v)}
            data-testid="switch-ip-restriction"
          />
        </div>
      </CardContent>
    </Card>
  );
}

function MastersSettings({ companyId, selectedCompany, userRole }: { companyId: string | undefined; selectedCompany: string; userRole: string | undefined }) {
  const { toast } = useToast();
  const [masterTab, setMasterTab] = useState("departments");

  if (!companyId && userRole !== "super_admin") {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Please select a company to manage master data.
        </CardContent>
      </Card>
    );
  }

  if (selectedCompany === "__global__" && userRole === "super_admin") {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Please select a specific company to manage master data. Master data is company-specific.
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Tabs value={masterTab} onValueChange={setMasterTab}>
        <TabsList>
          <TabsTrigger value="departments">Departments</TabsTrigger>
          <TabsTrigger value="designations">Designations</TabsTrigger>
          <TabsTrigger value="locations">Locations</TabsTrigger>
          <TabsTrigger value="earnings">Earning Heads</TabsTrigger>
          <TabsTrigger value="deductions">Deduction Heads</TabsTrigger>
        </TabsList>

        <TabsContent value="departments">
          <DepartmentsManager companyId={companyId!} />
        </TabsContent>
        <TabsContent value="designations">
          <DesignationsManager companyId={companyId!} />
        </TabsContent>
        <TabsContent value="locations">
          <LocationsManager companyId={companyId!} />
        </TabsContent>
        <TabsContent value="earnings">
          <EarningHeadsManager companyId={companyId!} />
        </TabsContent>
        <TabsContent value="deductions">
          <DeductionHeadsManager companyId={companyId!} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function DepartmentsManager({ companyId }: { companyId: string }) {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MasterDepartment | null>(null);
  const [formData, setFormData] = useState({ name: "", code: "", description: "" });

  const { data: departments = [], isLoading } = useQuery<MasterDepartment[]>({
    queryKey: ["/api/master-departments", companyId],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/master-departments", { ...data, companyId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-departments"] });
      toast({ title: "Department created successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PATCH", `/api/master-departments/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-departments"] });
      toast({ title: "Department updated successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/master-departments/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-departments"] });
      toast({ title: "Department deleted successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const resetForm = () => {
    setFormData({ name: "", code: "", description: "" });
    setEditingItem(null);
  };

  const handleEdit = (item: MasterDepartment) => {
    setEditingItem(item);
    setFormData({ name: item.name, code: item.code || "", description: item.description || "" });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              Departments
            </CardTitle>
            <CardDescription>Manage company departments</CardDescription>
          </div>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }} data-testid="button-add-department">
            <Plus className="h-4 w-4 mr-2" />
            Add Department
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-4">Loading...</div>
        ) : departments.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No departments configured. Click "Add Department" to create one.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {departments.map((dept) => (
                <TableRow key={dept.id} data-testid={`row-department-${dept.id}`}>
                  <TableCell className="font-medium">{dept.name}</TableCell>
                  <TableCell>{dept.code || "-"}</TableCell>
                  <TableCell>{dept.description || "-"}</TableCell>
                  <TableCell>
                    <Badge variant={dept.status === "active" ? "default" : "secondary"}>{dept.status}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => handleEdit(dept)} data-testid={`button-edit-department-${dept.id}`}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(dept.id)} data-testid={`button-delete-department-${dept.id}`}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Department" : "Add Department"}</DialogTitle>
            <DialogDescription>Enter department details below.</DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} data-testid="input-department-name" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="code">Code</Label>
              <Input id="code" value={formData.code} onChange={(e) => setFormData({ ...formData, code: e.target.value })} data-testid="input-department-code" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input id="description" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} data-testid="input-department-description" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-department">
              {editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function DesignationsManager({ companyId }: { companyId: string }) {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MasterDesignation | null>(null);
  const [formData, setFormData] = useState({ name: "", code: "", level: 1, description: "" });

  const { data: designations = [], isLoading } = useQuery<MasterDesignation[]>({
    queryKey: ["/api/master-designations", companyId],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/master-designations", { ...data, companyId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-designations"] });
      toast({ title: "Designation created successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PATCH", `/api/master-designations/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-designations"] });
      toast({ title: "Designation updated successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/master-designations/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-designations"] });
      toast({ title: "Designation deleted successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const resetForm = () => {
    setFormData({ name: "", code: "", level: 1, description: "" });
    setEditingItem(null);
  };

  const handleEdit = (item: MasterDesignation) => {
    setEditingItem(item);
    setFormData({ name: item.name, code: item.code || "", level: item.level || 1, description: item.description || "" });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <Briefcase className="h-5 w-5" />
              Designations
            </CardTitle>
            <CardDescription>Manage job titles and designations</CardDescription>
          </div>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }} data-testid="button-add-designation">
            <Plus className="h-4 w-4 mr-2" />
            Add Designation
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-4">Loading...</div>
        ) : designations.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No designations configured. Click "Add Designation" to create one.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Level</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {designations.map((desg) => (
                <TableRow key={desg.id} data-testid={`row-designation-${desg.id}`}>
                  <TableCell className="font-medium">{desg.name}</TableCell>
                  <TableCell>{desg.code || "-"}</TableCell>
                  <TableCell>{desg.level}</TableCell>
                  <TableCell>
                    <Badge variant={desg.status === "active" ? "default" : "secondary"}>{desg.status}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => handleEdit(desg)} data-testid={`button-edit-designation-${desg.id}`}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(desg.id)} data-testid={`button-delete-designation-${desg.id}`}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Designation" : "Add Designation"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} data-testid="input-designation-name" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="code">Code</Label>
                <Input id="code" value={formData.code} onChange={(e) => setFormData({ ...formData, code: e.target.value })} data-testid="input-designation-code" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="level">Level</Label>
                <Input id="level" type="number" value={formData.level} onChange={(e) => setFormData({ ...formData, level: parseInt(e.target.value) || 1 })} data-testid="input-designation-level" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Input id="description" value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} data-testid="input-designation-description" />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-designation">
              {editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function LocationsManager({ companyId }: { companyId: string }) {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<MasterLocation | null>(null);
  const [formData, setFormData] = useState({ name: "", code: "", address: "", city: "", state: "", country: "India" });

  const { data: locations = [], isLoading } = useQuery<MasterLocation[]>({
    queryKey: ["/api/master-locations", companyId],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/master-locations", { ...data, companyId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-locations"] });
      toast({ title: "Location created successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PATCH", `/api/master-locations/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-locations"] });
      toast({ title: "Location updated successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/master-locations/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/master-locations"] });
      toast({ title: "Location deleted successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const resetForm = () => {
    setFormData({ name: "", code: "", address: "", city: "", state: "", country: "India" });
    setEditingItem(null);
  };

  const handleEdit = (item: MasterLocation) => {
    setEditingItem(item);
    setFormData({ 
      name: item.name, 
      code: item.code || "", 
      address: item.address || "", 
      city: item.city || "", 
      state: item.state || "", 
      country: item.country || "India" 
    });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <MapPin className="h-5 w-5" />
              Locations
            </CardTitle>
            <CardDescription>Manage office locations and branches</CardDescription>
          </div>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }} data-testid="button-add-location">
            <Plus className="h-4 w-4 mr-2" />
            Add Location
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-4">Loading...</div>
        ) : locations.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No locations configured. Click "Add Location" to create one.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>City</TableHead>
                <TableHead>State</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {locations.map((loc) => (
                <TableRow key={loc.id} data-testid={`row-location-${loc.id}`}>
                  <TableCell className="font-medium">{loc.name}</TableCell>
                  <TableCell>{loc.code || "-"}</TableCell>
                  <TableCell>{loc.city || "-"}</TableCell>
                  <TableCell>{loc.state || "-"}</TableCell>
                  <TableCell>
                    <Badge variant={loc.status === "active" ? "default" : "secondary"}>{loc.status}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => handleEdit(loc)} data-testid={`button-edit-location-${loc.id}`}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(loc.id)} data-testid={`button-delete-location-${loc.id}`}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Location" : "Add Location"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} data-testid="input-location-name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="code">Code</Label>
                <Input id="code" value={formData.code} onChange={(e) => setFormData({ ...formData, code: e.target.value })} data-testid="input-location-code" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Input id="address" value={formData.address} onChange={(e) => setFormData({ ...formData, address: e.target.value })} data-testid="input-location-address" />
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="city">City</Label>
                <Input id="city" value={formData.city} onChange={(e) => setFormData({ ...formData, city: e.target.value })} data-testid="input-location-city" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="state">State</Label>
                <Input id="state" value={formData.state} onChange={(e) => setFormData({ ...formData, state: e.target.value })} data-testid="input-location-state" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="country">Country</Label>
                <Input id="country" value={formData.country} onChange={(e) => setFormData({ ...formData, country: e.target.value })} data-testid="input-location-country" />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-location">
              {editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function EarningHeadsManager({ companyId }: { companyId: string }) {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<EarningHead | null>(null);
  const [formData, setFormData] = useState({ name: "", code: "", type: "fixed", calculationBase: "", percentage: 0, isTaxable: true, isPartOfCTC: true });

  const { data: earningHeads = [], isLoading } = useQuery<EarningHead[]>({
    queryKey: ["/api/earning-heads", companyId],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/earning-heads", { ...data, companyId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/earning-heads"] });
      toast({ title: "Earning head created successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PATCH", `/api/earning-heads/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/earning-heads"] });
      toast({ title: "Earning head updated successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/earning-heads/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/earning-heads"] });
      toast({ title: "Earning head deleted successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const resetForm = () => {
    setFormData({ name: "", code: "", type: "fixed", calculationBase: "", percentage: 0, isTaxable: true, isPartOfCTC: true });
    setEditingItem(null);
  };

  const handleEdit = (item: EarningHead) => {
    setEditingItem(item);
    setFormData({ 
      name: item.name, 
      code: item.code, 
      type: item.type,
      calculationBase: item.calculationBase || "",
      percentage: item.percentage || 0,
      isTaxable: item.isTaxable ?? true,
      isPartOfCTC: item.isPartOfCTC ?? true
    });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <DollarSign className="h-5 w-5" />
              Earning Heads
            </CardTitle>
            <CardDescription>Manage salary earning components</CardDescription>
          </div>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }} data-testid="button-add-earning-head">
            <Plus className="h-4 w-4 mr-2" />
            Add Earning Head
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-4">Loading...</div>
        ) : earningHeads.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No earning heads configured. Click "Add Earning Head" to create one.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Taxable</TableHead>
                <TableHead>Part of CTC</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {earningHeads.map((head) => (
                <TableRow key={head.id} data-testid={`row-earning-head-${head.id}`}>
                  <TableCell className="font-medium">{head.name}</TableCell>
                  <TableCell>{head.code}</TableCell>
                  <TableCell className="capitalize">{head.type}</TableCell>
                  <TableCell>{head.isTaxable ? "Yes" : "No"}</TableCell>
                  <TableCell>{head.isPartOfCTC ? "Yes" : "No"}</TableCell>
                  <TableCell>
                    <Badge variant={head.status === "active" ? "default" : "secondary"}>{head.status}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => handleEdit(head)} data-testid={`button-edit-earning-head-${head.id}`}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(head.id)} data-testid={`button-delete-earning-head-${head.id}`}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Earning Head" : "Add Earning Head"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} data-testid="input-earning-head-name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="code">Code</Label>
                <Input id="code" value={formData.code} onChange={(e) => setFormData({ ...formData, code: e.target.value })} data-testid="input-earning-head-code" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v })}>
                  <SelectTrigger data-testid="select-earning-head-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fixed">Fixed</SelectItem>
                    <SelectItem value="percentage">Percentage</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formData.type === "percentage" && (
                <>
                  <div className="space-y-2">
                    <Label htmlFor="calculationBase">Calculation Base</Label>
                    <Select value={formData.calculationBase} onValueChange={(v) => setFormData({ ...formData, calculationBase: v })}>
                      <SelectTrigger data-testid="select-earning-head-base">
                        <SelectValue placeholder="Select base" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="basic">Basic</SelectItem>
                        <SelectItem value="gross">Gross</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </>
              )}
            </div>
            {formData.type === "percentage" && (
              <div className="space-y-2">
                <Label htmlFor="percentage">Percentage (%)</Label>
                <Input id="percentage" type="number" value={formData.percentage} onChange={(e) => setFormData({ ...formData, percentage: parseFloat(e.target.value) || 0 })} data-testid="input-earning-head-percentage" />
              </div>
            )}
            <div className="flex gap-6">
              <div className="flex items-center gap-2">
                <Switch checked={formData.isTaxable} onCheckedChange={(v) => setFormData({ ...formData, isTaxable: v })} data-testid="switch-earning-head-taxable" />
                <Label>Taxable</Label>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={formData.isPartOfCTC} onCheckedChange={(v) => setFormData({ ...formData, isPartOfCTC: v })} data-testid="switch-earning-head-ctc" />
                <Label>Part of CTC</Label>
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-earning-head">
              {editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function DeductionHeadsManager({ companyId }: { companyId: string }) {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<DeductionHead | null>(null);
  const [formData, setFormData] = useState({ name: "", code: "", type: "fixed", calculationBase: "", percentage: 0, isStatutory: false });

  const { data: deductionHeads = [], isLoading } = useQuery<DeductionHead[]>({
    queryKey: ["/api/deduction-heads", companyId],
  });

  const createMutation = useMutation({
    mutationFn: (data: any) => apiRequest("POST", "/api/deduction-heads", { ...data, companyId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/deduction-heads"] });
      toast({ title: "Deduction head created successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: any }) => apiRequest("PATCH", `/api/deduction-heads/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/deduction-heads"] });
      toast({ title: "Deduction head updated successfully" });
      setDialogOpen(false);
      resetForm();
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/deduction-heads/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/deduction-heads"] });
      toast({ title: "Deduction head deleted successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  const resetForm = () => {
    setFormData({ name: "", code: "", type: "fixed", calculationBase: "", percentage: 0, isStatutory: false });
    setEditingItem(null);
  };

  const handleEdit = (item: DeductionHead) => {
    setEditingItem(item);
    setFormData({ 
      name: item.name, 
      code: item.code, 
      type: item.type,
      calculationBase: item.calculationBase || "",
      percentage: item.percentage || 0,
      isStatutory: item.isStatutory ?? false
    });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (editingItem) {
      updateMutation.mutate({ id: editingItem.id, data: formData });
    } else {
      createMutation.mutate(formData);
    }
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <div>
            <CardTitle className="flex items-center gap-2">
              <FileText className="h-5 w-5" />
              Deduction Heads
            </CardTitle>
            <CardDescription>Manage salary deduction components</CardDescription>
          </div>
          <Button onClick={() => { resetForm(); setDialogOpen(true); }} data-testid="button-add-deduction-head">
            <Plus className="h-4 w-4 mr-2" />
            Add Deduction Head
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-4">Loading...</div>
        ) : deductionHeads.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            No deduction heads configured. Click "Add Deduction Head" to create one.
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Name</TableHead>
                <TableHead>Code</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Statutory</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="w-24">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {deductionHeads.map((head) => (
                <TableRow key={head.id} data-testid={`row-deduction-head-${head.id}`}>
                  <TableCell className="font-medium">{head.name}</TableCell>
                  <TableCell>{head.code}</TableCell>
                  <TableCell className="capitalize">{head.type}</TableCell>
                  <TableCell>{head.isStatutory ? "Yes" : "No"}</TableCell>
                  <TableCell>
                    <Badge variant={head.status === "active" ? "default" : "secondary"}>{head.status}</Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex gap-1">
                      <Button size="icon" variant="ghost" onClick={() => handleEdit(head)} data-testid={`button-edit-deduction-head-${head.id}`}>
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button size="icon" variant="ghost" onClick={() => deleteMutation.mutate(head.id)} data-testid={`button-delete-deduction-head-${head.id}`}>
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </CardContent>

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{editingItem ? "Edit Deduction Head" : "Add Deduction Head"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Name</Label>
                <Input id="name" value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} data-testid="input-deduction-head-name" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="code">Code</Label>
                <Input id="code" value={formData.code} onChange={(e) => setFormData({ ...formData, code: e.target.value })} data-testid="input-deduction-head-code" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="type">Type</Label>
                <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v })}>
                  <SelectTrigger data-testid="select-deduction-head-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fixed">Fixed</SelectItem>
                    <SelectItem value="percentage">Percentage</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              {formData.type === "percentage" && (
                <div className="space-y-2">
                  <Label htmlFor="calculationBase">Calculation Base</Label>
                  <Select value={formData.calculationBase} onValueChange={(v) => setFormData({ ...formData, calculationBase: v })}>
                    <SelectTrigger data-testid="select-deduction-head-base">
                      <SelectValue placeholder="Select base" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="basic">Basic</SelectItem>
                      <SelectItem value="gross">Gross</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              )}
            </div>
            {formData.type === "percentage" && (
              <div className="space-y-2">
                <Label htmlFor="percentage">Percentage (%)</Label>
                <Input id="percentage" type="number" value={formData.percentage} onChange={(e) => setFormData({ ...formData, percentage: parseFloat(e.target.value) || 0 })} data-testid="input-deduction-head-percentage" />
              </div>
            )}
            <div className="flex items-center gap-2">
              <Switch checked={formData.isStatutory} onCheckedChange={(v) => setFormData({ ...formData, isStatutory: v })} data-testid="switch-deduction-head-statutory" />
              <Label>Statutory Deduction</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSubmit} disabled={createMutation.isPending || updateMutation.isPending} data-testid="button-save-deduction-head">
              {editingItem ? "Update" : "Create"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </Card>
  );
}

function StatutorySettingsTab({ companyId, selectedCompany }: { companyId: string | undefined; selectedCompany: string }) {
  const { toast } = useToast();
  const { user } = useAuth();
  
  const [formData, setFormData] = useState({
    pfEmployeePercent: 12,
    pfEmployerPercent: 12,
    pfWageCeiling: 15000,
    pfEnabled: true,
    esicEmployeePercent: 75,
    esicEmployerPercent: 325,
    esicWageCeiling: 21000,
    esicEnabled: true,
    lwfEmployeeAmount: 0,
    lwfEmployerAmount: 0,
    lwfEnabled: false,
    ptMaxAmount: 200,
    ptEnabled: true,
    ptState: "",
  });

  const { data: statutorySettings, isLoading } = useQuery<StatutorySettings | null>({
    queryKey: ["/api/statutory-settings", companyId],
    enabled: !!companyId,
  });

  useEffect(() => {
    if (statutorySettings) {
      setFormData({
        pfEmployeePercent: statutorySettings.pfEmployeePercent ?? 12,
        pfEmployerPercent: statutorySettings.pfEmployerPercent ?? 12,
        pfWageCeiling: statutorySettings.pfWageCeiling ?? 15000,
        pfEnabled: statutorySettings.pfEnabled ?? true,
        esicEmployeePercent: statutorySettings.esicEmployeePercent ?? 75,
        esicEmployerPercent: statutorySettings.esicEmployerPercent ?? 325,
        esicWageCeiling: statutorySettings.esicWageCeiling ?? 21000,
        esicEnabled: statutorySettings.esicEnabled ?? true,
        lwfEmployeeAmount: statutorySettings.lwfEmployeeAmount ?? 0,
        lwfEmployerAmount: statutorySettings.lwfEmployerAmount ?? 0,
        lwfEnabled: statutorySettings.lwfEnabled ?? false,
        ptMaxAmount: statutorySettings.ptMaxAmount ?? 200,
        ptEnabled: statutorySettings.ptEnabled ?? true,
        ptState: statutorySettings.ptState || "",
      });
    }
  }, [statutorySettings]);

  const saveMutation = useMutation({
    mutationFn: (data: typeof formData) => 
      apiRequest("POST", "/api/statutory-settings", { ...data, companyId }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/statutory-settings"] });
      toast({ title: "Statutory settings saved successfully" });
    },
    onError: (error: Error) => toast({ title: "Error", description: error.message, variant: "destructive" }),
  });

  if (!companyId && user?.role !== "super_admin") {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Please select a company to configure statutory settings.
        </CardContent>
      </Card>
    );
  }

  if (selectedCompany === "__global__" && user?.role === "super_admin") {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Please select a specific company to configure statutory settings. These settings are company-specific.
        </CardContent>
      </Card>
    );
  }

  if (isLoading) {
    return (
      <Card>
        <CardContent className="py-8 text-center text-muted-foreground">
          Loading...
        </CardContent>
      </Card>
    );
  }

  const indianStates = [
    "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", 
    "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", 
    "Karnataka", "Kerala", "Madhya Pradesh", "Maharashtra", "Manipur", 
    "Meghalaya", "Mizoram", "Nagaland", "Odisha", "Punjab", 
    "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura", 
    "Uttar Pradesh", "Uttarakhand", "West Bengal"
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-end">
        <Button onClick={() => saveMutation.mutate(formData)} disabled={saveMutation.isPending} data-testid="button-save-statutory">
          <Save className="h-4 w-4 mr-2" />
          {saveMutation.isPending ? "Saving..." : "Save Statutory Settings"}
        </Button>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Provident Fund (PF)</CardTitle>
              <Switch 
                checked={formData.pfEnabled} 
                onCheckedChange={(v) => setFormData({ ...formData, pfEnabled: v })} 
                data-testid="switch-pf-enabled"
              />
            </div>
            <CardDescription>Employee Provident Fund contribution settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Employee Contribution (%)</Label>
                <Input 
                  type="number" 
                  value={formData.pfEmployeePercent} 
                  onChange={(e) => setFormData({ ...formData, pfEmployeePercent: parseInt(e.target.value) || 0 })}
                  disabled={!formData.pfEnabled}
                  data-testid="input-pf-employee-percent"
                />
              </div>
              <div className="space-y-2">
                <Label>Employer Contribution (%)</Label>
                <Input 
                  type="number" 
                  value={formData.pfEmployerPercent} 
                  onChange={(e) => setFormData({ ...formData, pfEmployerPercent: parseInt(e.target.value) || 0 })}
                  disabled={!formData.pfEnabled}
                  data-testid="input-pf-employer-percent"
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Wage Ceiling (Monthly)</Label>
              <Input 
                type="number" 
                value={formData.pfWageCeiling} 
                onChange={(e) => setFormData({ ...formData, pfWageCeiling: parseInt(e.target.value) || 0 })}
                disabled={!formData.pfEnabled}
                data-testid="input-pf-ceiling"
              />
              <p className="text-xs text-muted-foreground">PF contribution is calculated on basic up to this limit</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">ESIC</CardTitle>
              <Switch 
                checked={formData.esicEnabled} 
                onCheckedChange={(v) => setFormData({ ...formData, esicEnabled: v })} 
                data-testid="switch-esic-enabled"
              />
            </div>
            <CardDescription>Employee State Insurance Corporation settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Employee Contribution (%)</Label>
                <Input 
                  type="number" 
                  step="0.01"
                  value={(formData.esicEmployeePercent / 100).toFixed(2)} 
                  onChange={(e) => setFormData({ ...formData, esicEmployeePercent: Math.round(parseFloat(e.target.value) * 100) || 0 })}
                  disabled={!formData.esicEnabled}
                  data-testid="input-esic-employee-percent"
                />
                <p className="text-xs text-muted-foreground">Standard: 0.75%</p>
              </div>
              <div className="space-y-2">
                <Label>Employer Contribution (%)</Label>
                <Input 
                  type="number" 
                  step="0.01"
                  value={(formData.esicEmployerPercent / 100).toFixed(2)} 
                  onChange={(e) => setFormData({ ...formData, esicEmployerPercent: Math.round(parseFloat(e.target.value) * 100) || 0 })}
                  disabled={!formData.esicEnabled}
                  data-testid="input-esic-employer-percent"
                />
                <p className="text-xs text-muted-foreground">Standard: 3.25%</p>
              </div>
            </div>
            <div className="space-y-2">
              <Label>Wage Ceiling (Monthly)</Label>
              <Input 
                type="number" 
                value={formData.esicWageCeiling} 
                onChange={(e) => setFormData({ ...formData, esicWageCeiling: parseInt(e.target.value) || 0 })}
                disabled={!formData.esicEnabled}
                data-testid="input-esic-ceiling"
              />
              <p className="text-xs text-muted-foreground">ESIC is applicable for employees with gross up to this limit</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Labour Welfare Fund (LWF)</CardTitle>
              <Switch 
                checked={formData.lwfEnabled} 
                onCheckedChange={(v) => setFormData({ ...formData, lwfEnabled: v })} 
                data-testid="switch-lwf-enabled"
              />
            </div>
            <CardDescription>State-specific Labour Welfare Fund settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Employee Amount</Label>
                <Input 
                  type="number" 
                  value={formData.lwfEmployeeAmount} 
                  onChange={(e) => setFormData({ ...formData, lwfEmployeeAmount: parseInt(e.target.value) || 0 })}
                  disabled={!formData.lwfEnabled}
                  data-testid="input-lwf-employee-amount"
                />
              </div>
              <div className="space-y-2">
                <Label>Employer Amount</Label>
                <Input 
                  type="number" 
                  value={formData.lwfEmployerAmount} 
                  onChange={(e) => setFormData({ ...formData, lwfEmployerAmount: parseInt(e.target.value) || 0 })}
                  disabled={!formData.lwfEnabled}
                  data-testid="input-lwf-employer-amount"
                />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">LWF amounts vary by state and are typically deducted monthly or half-yearly</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle className="text-lg">Professional Tax (PT)</CardTitle>
              <Switch 
                checked={formData.ptEnabled} 
                onCheckedChange={(v) => setFormData({ ...formData, ptEnabled: v })} 
                data-testid="switch-pt-enabled"
              />
            </div>
            <CardDescription>State-specific Professional Tax settings</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>State</Label>
              <Select 
                value={formData.ptState} 
                onValueChange={(v) => setFormData({ ...formData, ptState: v })}
                disabled={!formData.ptEnabled}
              >
                <SelectTrigger data-testid="select-pt-state">
                  <SelectValue placeholder="Select state" />
                </SelectTrigger>
                <SelectContent>
                  {indianStates.map(state => (
                    <SelectItem key={state} value={state}>{state}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Maximum Monthly Amount</Label>
              <Input 
                type="number" 
                value={formData.ptMaxAmount} 
                onChange={(e) => setFormData({ ...formData, ptMaxAmount: parseInt(e.target.value) || 0 })}
                disabled={!formData.ptEnabled}
                data-testid="input-pt-max-amount"
              />
              <p className="text-xs text-muted-foreground">PT is calculated based on salary slabs defined by each state (max Rs. 200/month)</p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
