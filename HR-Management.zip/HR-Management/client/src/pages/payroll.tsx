import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { format } from "date-fns";
import { DollarSign, Plus, FileText, Users, Calculator, Download, Building2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Payroll, SalaryStructure, Employee, Company, StatutorySettings } from "@shared/schema";

const salaryStructureSchema = z.object({
  employeeId: z.string().min(1, "Employee is required"),
  companyId: z.string().min(1, "Company is required"),
  basicSalary: z.coerce.number().min(1, "Basic salary is required"),
  hra: z.coerce.number().default(0),
  conveyance: z.coerce.number().default(0),
  medicalAllowance: z.coerce.number().default(0),
  specialAllowance: z.coerce.number().default(0),
  otherAllowances: z.coerce.number().default(0),
  grossSalary: z.coerce.number(),
  pfEmployee: z.coerce.number().default(0),
  pfEmployer: z.coerce.number().default(0),
  esi: z.coerce.number().default(0),
  professionalTax: z.coerce.number().default(0),
  tds: z.coerce.number().default(0),
  otherDeductions: z.coerce.number().default(0),
  netSalary: z.coerce.number(),
  effectiveFrom: z.string().min(1, "Effective date is required"),
});

type SalaryStructureFormValues = z.infer<typeof salaryStructureSchema>;

const statusColors: Record<string, string> = {
  draft: "bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-300",
  processed: "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300",
  paid: "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
};

const months = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

export default function PayrollPage() {
  const { toast } = useToast();
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<string>("__all__");
  const [selectedMonth, setSelectedMonth] = useState(months[new Date().getMonth()]);
  const [selectedYear, setSelectedYear] = useState(new Date().getFullYear().toString());

  const { data: companies = [] } = useQuery<Company[]>({
    queryKey: ["/api/companies"],
  });

  const { data: employees = [] } = useQuery<Employee[]>({
    queryKey: ["/api/employees"],
  });

  const { data: salaryStructures = [], isLoading: isLoadingStructures } = useQuery<SalaryStructure[]>({
    queryKey: ["/api/salary-structures"],
  });

  const { data: payrollRecords = [], isLoading: isLoadingPayroll } = useQuery<Payroll[]>({
    queryKey: ["/api/payroll"],
  });

  const { data: statutorySettings = [] } = useQuery<StatutorySettings[]>({
    queryKey: ["/api/statutory-settings"],
  });

  const filteredStructures = selectedCompany === "__all__"
    ? salaryStructures
    : salaryStructures.filter(s => s.companyId === selectedCompany);

  const filteredPayroll = payrollRecords.filter(p => 
    (selectedCompany === "__all__" || p.companyId === selectedCompany) &&
    p.month === selectedMonth &&
    p.year === parseInt(selectedYear)
  );

  const form = useForm<SalaryStructureFormValues>({
    resolver: zodResolver(salaryStructureSchema),
    defaultValues: {
      employeeId: "",
      companyId: "",
      basicSalary: 0,
      hra: 0,
      conveyance: 0,
      medicalAllowance: 0,
      specialAllowance: 0,
      otherAllowances: 0,
      grossSalary: 0,
      pfEmployee: 0,
      pfEmployer: 0,
      esi: 0,
      professionalTax: 0,
      tds: 0,
      otherDeductions: 0,
      netSalary: 0,
      effectiveFrom: format(new Date(), "yyyy-MM-dd"),
    },
  });

  const getStatutorySettingsForCompany = (companyId: string) => {
    return statutorySettings.find(s => s.companyId === companyId);
  };

  const calculateStatutoryDeductions = (companyId: string, employeeId: string, basicSalary: number, grossSalary: number) => {
    const settings = getStatutorySettingsForCompany(companyId);
    const employee = employees.find(e => e.id === employeeId);

    let pfEmployee = 0;
    let pfEmployer = 0;
    let esi = 0;
    let pt = 0;

    // Calculate PF (12% of basic or ceiling of ₹15,000) - only if employee is PF applicable
    if (settings?.pfEnabled && employee?.pfApplicable) {
      const pfBase = Math.min(basicSalary, settings.pfWageCeiling || 15000);
      pfEmployee = Math.round(pfBase * (settings.pfEmployeePercent || 12) / 100);
      pfEmployer = Math.round(pfBase * (settings.pfEmployerPercent || 12) / 100);
    }

    // Calculate ESI (0.75% employee, 3.25% employer if gross <= ₹21,000) - only if employee is ESI applicable
    if (settings?.esicEnabled && employee?.esiApplicable && grossSalary <= (settings.esicWageCeiling || 21000)) {
      // esicEmployeePercent is stored as 75 for 0.75%
      esi = Math.round(grossSalary * (settings.esicEmployeePercent || 75) / 10000);
    }

    // Calculate PT (fixed amount from settings, max ₹200/month) - applies to all employees
    if (settings?.ptEnabled) {
      pt = Math.min(settings.ptMaxAmount || 200, 200);
    }

    return { pfEmployee, pfEmployer, esi, pt };
  };

  const calculateSalary = (autoCalculateStatutory = true) => {
    const companyId = form.watch("companyId");
    const employeeId = form.watch("employeeId");
    const basic = form.watch("basicSalary") || 0;
    const hra = form.watch("hra") || 0;
    const conveyance = form.watch("conveyance") || 0;
    const medical = form.watch("medicalAllowance") || 0;
    const special = form.watch("specialAllowance") || 0;
    const other = form.watch("otherAllowances") || 0;
    
    const gross = basic + hra + conveyance + medical + special + other;
    form.setValue("grossSalary", gross);
    
    // Auto-calculate statutory deductions if enabled and employee is selected
    if (autoCalculateStatutory && companyId && employeeId) {
      const statutory = calculateStatutoryDeductions(companyId, employeeId, basic, gross);
      form.setValue("pfEmployee", statutory.pfEmployee);
      form.setValue("pfEmployer", statutory.pfEmployer);
      form.setValue("esi", statutory.esi);
      form.setValue("professionalTax", statutory.pt);
    }
    
    const pfEmp = form.watch("pfEmployee") || 0;
    const esi = form.watch("esi") || 0;
    const pt = form.watch("professionalTax") || 0;
    const tds = form.watch("tds") || 0;
    const otherDed = form.watch("otherDeductions") || 0;
    
    const totalDeductions = pfEmp + esi + pt + tds + otherDed;
    const net = gross - totalDeductions;
    
    form.setValue("netSalary", net);
  };

  const createStructureMutation = useMutation({
    mutationFn: async (data: SalaryStructureFormValues) => {
      return apiRequest("POST", "/api/salary-structures", data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/salary-structures"] });
      setIsCreateOpen(false);
      form.reset();
      toast({
        title: "Salary Structure Created",
        description: "The salary structure has been created successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const generatePayrollMutation = useMutation({
    mutationFn: async (companyId: string) => {
      const companyEmployees = employees.filter(e => e.companyId === companyId);
      const payrollData = companyEmployees.map(emp => {
        const structure = salaryStructures.find(s => s.employeeId === emp.id);
        return {
          employeeId: emp.id,
          companyId: companyId,
          month: selectedMonth,
          year: parseInt(selectedYear),
          basicSalary: structure?.basicSalary || emp.grossSalary || 0,
          totalEarnings: structure?.grossSalary || emp.grossSalary || 0,
          totalDeductions: (structure?.pfEmployee || 0) + (structure?.esi || 0) + (structure?.professionalTax || 0),
          netSalary: structure?.netSalary || emp.grossSalary || 0,
          workingDays: 22,
          presentDays: 22,
          leaveDays: 0,
          status: "draft",
          generatedAt: new Date().toISOString(),
        };
      });
      
      for (const data of payrollData) {
        await apiRequest("POST", "/api/payroll", data);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/payroll"] });
      toast({
        title: "Payroll Generated",
        description: `Payroll for ${selectedMonth} ${selectedYear} has been generated.`,
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const getEmployeeName = (employeeId: string) => {
    const employee = employees.find(e => e.id === employeeId);
    return employee ? `${employee.firstName} ${employee.lastName}` : "Unknown";
  };

  const getCompanyName = (companyId: string) => {
    const company = companies.find(c => c.id === companyId);
    return company?.companyName || "Unknown";
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat("en-IN", {
      style: "currency",
      currency: "INR",
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const totalPayroll = filteredPayroll.reduce((sum, p) => sum + p.netSalary, 0);
  const totalEarnings = filteredPayroll.reduce((sum, p) => sum + p.totalEarnings, 0);
  const totalDeductions = filteredPayroll.reduce((sum, p) => sum + p.totalDeductions, 0);

  return (
    <div className="p-6" data-testid="payroll-page">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold">Payroll Management</h1>
          <p className="text-muted-foreground">Manage salary structures and process payroll</p>
        </div>
        <Dialog open={isCreateOpen} onOpenChange={setIsCreateOpen}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-structure">
              <Plus className="h-4 w-4 mr-2" />
              Add Salary Structure
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>Create Salary Structure</DialogTitle>
              <DialogDescription>Define salary components for an employee</DialogDescription>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => createStructureMutation.mutate(data))} className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="companyId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Company</FormLabel>
                        <Select 
                          value={field.value} 
                          onValueChange={(value) => {
                            field.onChange(value);
                            form.setValue("employeeId", "");
                          }}
                        >
                          <FormControl>
                            <SelectTrigger data-testid="select-structure-company">
                              <SelectValue placeholder="Select company" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {companies.map((company) => (
                              <SelectItem key={company.id} value={company.id}>{company.companyName}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="employeeId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Employee</FormLabel>
                        <Select value={field.value} onValueChange={field.onChange}>
                          <FormControl>
                            <SelectTrigger data-testid="select-structure-employee">
                              <SelectValue placeholder="Select employee" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {employees
                              .filter(e => e.companyId === form.watch("companyId"))
                              .map((emp) => (
                                <SelectItem key={emp.id} value={emp.id}>
                                  {emp.firstName} {emp.lastName}
                                </SelectItem>
                              ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-3">Earnings</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="basicSalary"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Basic Salary</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(); }} data-testid="input-basic-salary" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="hra"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>HRA</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(); }} data-testid="input-hra" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="conveyance"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Conveyance</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(); }} data-testid="input-conveyance" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="medicalAllowance"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Medical Allowance</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(); }} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="specialAllowance"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Special Allowance</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(); }} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="grossSalary"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Gross Salary</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} readOnly className="bg-muted" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <div className="border-t pt-4">
                  <h4 className="font-medium mb-3">Deductions</h4>
                  <div className="grid grid-cols-3 gap-4">
                    <FormField
                      control={form.control}
                      name="pfEmployee"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>PF (Employee) - Auto-calculated</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(false); }} data-testid="input-pf" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="esi"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>ESI - Auto-calculated</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(false); }} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="professionalTax"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>PT - Auto-calculated</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(false); }} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="tds"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>TDS</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} onChange={(e) => { field.onChange(e); calculateSalary(false); }} />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="netSalary"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Net Salary</FormLabel>
                          <FormControl>
                            <Input type="number" {...field} readOnly className="bg-muted font-bold" />
                          </FormControl>
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <FormField
                  control={form.control}
                  name="effectiveFrom"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Effective From</FormLabel>
                      <FormControl>
                        <Input type="date" {...field} data-testid="input-effective-date" />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <DialogFooter>
                  <Button type="submit" disabled={createStructureMutation.isPending} data-testid="button-submit-structure">
                    {createStructureMutation.isPending ? "Creating..." : "Create Structure"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Payroll</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrency(totalPayroll)}</div>
            <p className="text-xs text-muted-foreground">{selectedMonth} {selectedYear}</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Earnings</CardTitle>
            <Calculator className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrency(totalEarnings)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Deductions</CardTitle>
            <Calculator className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrency(totalDeductions)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Employees</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{filteredPayroll.length}</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="payroll">
        <TabsList className="mb-4">
          <TabsTrigger value="payroll" data-testid="tab-payroll">Payroll</TabsTrigger>
          <TabsTrigger value="structures" data-testid="tab-structures">Salary Structures</TabsTrigger>
        </TabsList>

        <TabsContent value="payroll">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Payroll Records</CardTitle>
                  <CardDescription>View and process monthly payroll</CardDescription>
                </div>
                <div className="flex items-center gap-4">
                  <Select value={selectedCompany} onValueChange={setSelectedCompany}>
                    <SelectTrigger className="w-48" data-testid="select-payroll-company">
                      <SelectValue placeholder="All Companies" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="__all__">All Companies</SelectItem>
                      {companies.map((company) => (
                        <SelectItem key={company.id} value={company.id}>{company.companyName}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={selectedMonth} onValueChange={setSelectedMonth}>
                    <SelectTrigger className="w-36" data-testid="select-payroll-month">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {months.map((month) => (
                        <SelectItem key={month} value={month}>{month}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <Select value={selectedYear} onValueChange={setSelectedYear}>
                    <SelectTrigger className="w-24" data-testid="select-payroll-year">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {[2024, 2025, 2026].map((year) => (
                        <SelectItem key={year} value={year.toString()}>{year}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {companies.length > 0 && selectedCompany !== "__all__" && (
                    <Button 
                      onClick={() => generatePayrollMutation.mutate(selectedCompany)}
                      disabled={generatePayrollMutation.isPending}
                      data-testid="button-generate-payroll"
                    >
                      <Calculator className="h-4 w-4 mr-2" />
                      Generate Payroll
                    </Button>
                  )}
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {isLoadingPayroll ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : filteredPayroll.length === 0 ? (
                <div className="text-center py-12">
                  <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No payroll records</h3>
                  <p className="text-muted-foreground">Generate payroll for the selected period</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead>Company</TableHead>
                      <TableHead className="text-right">Earnings</TableHead>
                      <TableHead className="text-right">Deductions</TableHead>
                      <TableHead className="text-right">Net Salary</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredPayroll.map((record) => (
                      <TableRow key={record.id} data-testid={`row-payroll-${record.id}`}>
                        <TableCell className="font-medium">{getEmployeeName(record.employeeId)}</TableCell>
                        <TableCell>{getCompanyName(record.companyId)}</TableCell>
                        <TableCell className="text-right text-green-600">{formatCurrency(record.totalEarnings)}</TableCell>
                        <TableCell className="text-right text-red-600">{formatCurrency(record.totalDeductions)}</TableCell>
                        <TableCell className="text-right font-bold">{formatCurrency(record.netSalary)}</TableCell>
                        <TableCell>
                          <Badge className={statusColors[record.status] || ""}>
                            {record.status.charAt(0).toUpperCase() + record.status.slice(1)}
                          </Badge>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="structures">
          <Card>
            <CardHeader>
              <CardTitle>Salary Structures</CardTitle>
              <CardDescription>Employee salary components and breakdowns</CardDescription>
            </CardHeader>
            <CardContent>
              {isLoadingStructures ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-12 w-full" />
                  ))}
                </div>
              ) : filteredStructures.length === 0 ? (
                <div className="text-center py-12">
                  <Building2 className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-medium mb-2">No salary structures</h3>
                  <p className="text-muted-foreground">Add salary structures for employees</p>
                </div>
              ) : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Employee</TableHead>
                      <TableHead className="text-right">Basic</TableHead>
                      <TableHead className="text-right">HRA</TableHead>
                      <TableHead className="text-right">Gross</TableHead>
                      <TableHead className="text-right">Deductions</TableHead>
                      <TableHead className="text-right">Net</TableHead>
                      <TableHead>Effective</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredStructures.map((structure) => (
                      <TableRow key={structure.id} data-testid={`row-structure-${structure.id}`}>
                        <TableCell className="font-medium">{getEmployeeName(structure.employeeId)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(structure.basicSalary)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(structure.hra || 0)}</TableCell>
                        <TableCell className="text-right">{formatCurrency(structure.grossSalary)}</TableCell>
                        <TableCell className="text-right text-red-600">
                          {formatCurrency((structure.pfEmployee || 0) + (structure.esi || 0) + (structure.professionalTax || 0) + (structure.tds || 0))}
                        </TableCell>
                        <TableCell className="text-right font-bold">{formatCurrency(structure.netSalary)}</TableCell>
                        <TableCell>{format(new Date(structure.effectiveFrom), "MMM d, yyyy")}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
