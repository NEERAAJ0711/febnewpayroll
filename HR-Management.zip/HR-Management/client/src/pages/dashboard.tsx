import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { 
  Building2, 
  Users, 
  UserCheck, 
  TrendingUp,
  Briefcase,
  MapPin
} from "lucide-react";
import type { DashboardStats, Employee } from "@shared/schema";

function StatCard({ 
  title, 
  value, 
  icon: Icon, 
  description,
  trend
}: { 
  title: string; 
  value: number | string; 
  icon: React.ElementType;
  description?: string;
  trend?: string;
}) {
  return (
    <Card data-testid={`stat-card-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">{title}</CardTitle>
        <div className="h-8 w-8 rounded-md bg-primary/10 flex items-center justify-center">
          <Icon className="h-4 w-4 text-primary" />
        </div>
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
        {trend && (
          <div className="flex items-center gap-1 mt-2">
            <TrendingUp className="h-3 w-3 text-green-500" />
            <span className="text-xs text-green-500">{trend}</span>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function DepartmentDistribution({ data }: { data: { department: string; count: number }[] }) {
  const total = data.reduce((sum, d) => sum + d.count, 0);
  const colors = [
    "bg-primary",
    "bg-emerald-500",
    "bg-amber-500",
    "bg-violet-500",
    "bg-cyan-500",
    "bg-pink-500",
    "bg-orange-500",
    "bg-teal-500"
  ];

  return (
    <Card data-testid="department-distribution">
      <CardHeader>
        <CardTitle className="text-base font-semibold">Department Distribution</CardTitle>
      </CardHeader>
      <CardContent>
        {data.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-8">
            No department data available
          </div>
        ) : (
          <div className="space-y-4">
            {data.map((dept, index) => {
              const percentage = total > 0 ? Math.round((dept.count / total) * 100) : 0;
              return (
                <div key={dept.department} className="space-y-2">
                  <div className="flex items-center justify-between text-sm">
                    <span className="font-medium">{dept.department}</span>
                    <span className="text-muted-foreground">{dept.count} employees</span>
                  </div>
                  <div className="h-2 rounded-full bg-muted overflow-hidden">
                    <div 
                      className={`h-full rounded-full ${colors[index % colors.length]}`}
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function RecentEmployees({ employees }: { employees: Employee[] }) {
  return (
    <Card data-testid="recent-employees">
      <CardHeader>
        <CardTitle className="text-base font-semibold">Recent Employees</CardTitle>
      </CardHeader>
      <CardContent>
        {employees.length === 0 ? (
          <div className="text-sm text-muted-foreground text-center py-8">
            No employees added yet
          </div>
        ) : (
          <div className="space-y-4">
            {employees.map((employee) => (
              <div 
                key={employee.id} 
                className="flex items-center gap-3"
                data-testid={`recent-employee-${employee.id}`}
              >
                <Avatar className="h-10 w-10">
                  <AvatarFallback className="bg-primary/10 text-primary text-sm">
                    {employee.firstName[0]}{employee.lastName[0]}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1 min-w-0">
                  <div className="font-medium text-sm">
                    {employee.firstName} {employee.lastName}
                  </div>
                  <div className="flex items-center gap-2 text-xs text-muted-foreground">
                    <Briefcase className="h-3 w-3" />
                    <span className="truncate">{employee.designation || "Not specified"}</span>
                  </div>
                </div>
                <Badge variant="secondary" className="text-xs">
                  {employee.department || "Unassigned"}
                </Badge>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function QuickStats({ stats }: { stats: DashboardStats }) {
  return (
    <Card data-testid="quick-stats">
      <CardHeader>
        <CardTitle className="text-base font-semibold">Quick Overview</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-emerald-500/10 flex items-center justify-center">
              <UserCheck className="h-5 w-5 text-emerald-500" />
            </div>
            <div>
              <div className="text-sm font-medium">Active Employees</div>
              <div className="text-xs text-muted-foreground">Currently working</div>
            </div>
          </div>
          <div className="text-2xl font-bold">{stats.activeEmployees}</div>
        </div>

        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-primary/10 flex items-center justify-center">
              <Building2 className="h-5 w-5 text-primary" />
            </div>
            <div>
              <div className="text-sm font-medium">Companies</div>
              <div className="text-xs text-muted-foreground">Registered organizations</div>
            </div>
          </div>
          <div className="text-2xl font-bold">{stats.totalCompanies}</div>
        </div>

        <div className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-md bg-violet-500/10 flex items-center justify-center">
              <Users className="h-5 w-5 text-violet-500" />
            </div>
            <div>
              <div className="text-sm font-medium">System Users</div>
              <div className="text-xs text-muted-foreground">Total accounts</div>
            </div>
          </div>
          <div className="text-2xl font-bold">{stats.totalUsers}</div>
        </div>
      </CardContent>
    </Card>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[...Array(4)].map((_, i) => (
          <Card key={i}>
            <CardHeader className="flex flex-row items-center justify-between gap-2 pb-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-8 w-8 rounded-md" />
            </CardHeader>
            <CardContent>
              <Skeleton className="h-8 w-16" />
              <Skeleton className="h-3 w-32 mt-2" />
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {[...Array(3)].map((_, i) => (
          <Card key={i}>
            <CardHeader>
              <Skeleton className="h-5 w-40" />
            </CardHeader>
            <CardContent className="space-y-4">
              {[...Array(4)].map((_, j) => (
                <Skeleton key={j} className="h-12 w-full" />
              ))}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard/stats"],
  });

  if (isLoading) {
    return (
      <div className="p-6">
        <div className="mb-6">
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-muted-foreground">Welcome to HRMS Pro - Your complete HR management solution</p>
        </div>
        <DashboardSkeleton />
      </div>
    );
  }

  const dashboardStats = stats || {
    totalCompanies: 0,
    totalEmployees: 0,
    totalUsers: 0,
    activeEmployees: 0,
    departmentDistribution: [],
    recentEmployees: [],
  };

  return (
    <div className="p-6" data-testid="dashboard-page">
      <div className="mb-6">
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">Welcome to HRMS Pro - Your complete HR management solution</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4 mb-6">
        <StatCard
          title="Total Companies"
          value={dashboardStats.totalCompanies}
          icon={Building2}
          description="Registered organizations"
        />
        <StatCard
          title="Total Employees"
          value={dashboardStats.totalEmployees}
          icon={Users}
          description="Across all companies"
        />
        <StatCard
          title="Active Employees"
          value={dashboardStats.activeEmployees}
          icon={UserCheck}
          description="Currently employed"
          trend="+12% this month"
        />
        <StatCard
          title="System Users"
          value={dashboardStats.totalUsers}
          icon={MapPin}
          description="With system access"
        />
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        <DepartmentDistribution data={dashboardStats.departmentDistribution} />
        <RecentEmployees employees={dashboardStats.recentEmployees} />
        <QuickStats stats={dashboardStats} />
      </div>
    </div>
  );
}
