# HRMS Pro - Multi-Company Human Resource Management System

## Overview
HRMS Pro is an enterprise-grade Multi-Company Human Resource Management System designed for managing employees, payroll, attendance, and compliance across multiple organizations. This MVP includes Phase 1 (Company, User, Employee management) and Phase 2 (Attendance, Leave, Payroll, Settings).

## Architecture

### Frontend
- **Framework**: React with TypeScript
- **Routing**: Wouter
- **State Management**: TanStack Query (React Query)
- **UI Components**: Shadcn/UI with Tailwind CSS
- **Theme**: Professional blue enterprise theme with dark mode support

### Backend
- **Framework**: Express.js with TypeScript
- **Storage**: In-memory storage (MemStorage) for MVP
- **Authentication**: Session-based authentication
- **Validation**: Zod schemas

### Data Models
- **Company**: Multi-tenant organization entities with India compliance fields (PAN, GSTIN, PF, ESI)
- **User**: System users with role-based access (Super Admin, Company Admin, HR Admin, etc.)
- **Employee**: Workforce records with job details, statutory info, and bank/KYC data
- **Attendance**: Daily attendance records with clock in/out, status, and work hours
- **LeaveType**: Leave policies (CL, SL, PL, ML, PTL) with carry-forward rules
- **LeaveRequest**: Employee leave applications with approval workflow
- **SalaryStructure**: Employee salary components (basic, allowances, deductions)
- **Payroll**: Monthly payroll records with earnings/deductions breakdown
- **Setting**: System and company-specific configuration
- **MasterDepartment**: Company-specific department definitions
- **MasterDesignation**: Company-specific designation/role definitions
- **MasterLocation**: Company-specific work location definitions
- **EarningHead**: Company-specific earning components (basic, HRA, allowances)
- **DeductionHead**: Company-specific deduction components (PF, ESI, loans)
- **StatutorySettings**: Company-specific PF, ESIC, LWF, PT configuration

## Project Structure

```
├── client/
│   ├── src/
│   │   ├── components/
│   │   │   ├── ui/           # Shadcn UI components
│   │   │   ├── app-sidebar.tsx
│   │   │   ├── theme-provider.tsx
│   │   │   └── theme-toggle.tsx
│   │   ├── pages/
│   │   │   ├── dashboard.tsx
│   │   │   ├── companies.tsx
│   │   │   ├── employees.tsx
│   │   │   ├── users.tsx
│   │   │   ├── attendance.tsx
│   │   │   ├── leave.tsx
│   │   │   ├── payroll.tsx
│   │   │   ├── settings.tsx
│   │   │   ├── login.tsx
│   │   │   ├── signup.tsx
│   │   │   └── not-found.tsx
│   │   ├── lib/
│   │   │   ├── queryClient.ts
│   │   │   └── auth.tsx
│   │   ├── App.tsx
│   │   └── index.css
├── server/
│   ├── routes.ts             # API endpoints
│   ├── storage.ts            # In-memory data storage
│   └── index.ts
├── shared/
│   └── schema.ts             # Data models and Zod schemas
└── package.json
```

## API Endpoints

### Authentication
- `POST /api/login` - User login
- `POST /api/logout` - User logout
- `GET /api/auth/me` - Get current user

### Dashboard
- `GET /api/dashboard/stats` - Get dashboard statistics

### Companies
- `GET /api/companies` - List all companies
- `GET /api/companies/:id` - Get company by ID
- `POST /api/companies` - Create company
- `PATCH /api/companies/:id` - Update company
- `DELETE /api/companies/:id` - Delete company

### Users
- `GET /api/users` - List all users
- `GET /api/users/:id` - Get user by ID
- `POST /api/users` - Create user
- `PATCH /api/users/:id` - Update user
- `DELETE /api/users/:id` - Delete user

### Employees
- `GET /api/employees` - List all employees
- `GET /api/employees?companyId=xxx` - List employees by company
- `GET /api/employees/:id` - Get employee by ID
- `POST /api/employees` - Create employee
- `PATCH /api/employees/:id` - Update employee
- `DELETE /api/employees/:id` - Delete employee

### Attendance
- `GET /api/attendance` - List all attendance records
- `GET /api/attendance?employeeId=xxx` - Get attendance by employee
- `GET /api/attendance?companyId=xxx&date=YYYY-MM-DD` - Get attendance by company and date
- `POST /api/attendance` - Record attendance
- `PATCH /api/attendance/:id` - Update attendance
- `DELETE /api/attendance/:id` - Delete attendance

### Leave Types
- `GET /api/leave-types` - List all leave types
- `GET /api/leave-types?companyId=xxx` - Get leave types by company
- `POST /api/leave-types` - Create leave type
- `PATCH /api/leave-types/:id` - Update leave type
- `DELETE /api/leave-types/:id` - Delete leave type

### Leave Requests
- `GET /api/leave-requests` - List all leave requests
- `GET /api/leave-requests?companyId=xxx` - Get leave requests by company
- `GET /api/leave-requests?employeeId=xxx` - Get leave requests by employee
- `POST /api/leave-requests` - Submit leave request
- `PATCH /api/leave-requests/:id` - Update leave request (approve/reject)
- `DELETE /api/leave-requests/:id` - Delete leave request

### Salary Structures
- `GET /api/salary-structures` - List all salary structures
- `GET /api/salary-structures?employeeId=xxx` - Get salary structure by employee
- `POST /api/salary-structures` - Create salary structure
- `PATCH /api/salary-structures/:id` - Update salary structure
- `DELETE /api/salary-structures/:id` - Delete salary structure

### Payroll
- `GET /api/payroll` - List all payroll records
- `GET /api/payroll?companyId=xxx&month=xxx&year=xxxx` - Get payroll by company and period
- `GET /api/payroll?employeeId=xxx` - Get payroll by employee
- `POST /api/payroll` - Generate payroll
- `PATCH /api/payroll/:id` - Update payroll
- `DELETE /api/payroll/:id` - Delete payroll

### Settings
- `GET /api/settings` - List all settings
- `GET /api/settings?companyId=xxx&category=xxx` - Get settings by company and category
- `POST /api/settings` - Create/update setting
- `PATCH /api/settings/:id` - Update setting
- `DELETE /api/settings/:id` - Delete setting

## Default Data

### Leave Types (Auto-initialized)
- **CL** - Casual Leave: 12 days/year, no carry forward
- **SL** - Sick Leave: 12 days/year, carry forward up to 6 days
- **PL** - Privilege Leave: 15 days/year, carry forward up to 30 days
- **ML** - Maternity Leave: 182 days/year, no carry forward
- **PTL** - Paternity Leave: 15 days/year, no carry forward

### Default Admin User
- Username: admin
- Password: admin123
- Email: admin@hrms.com
- Role: Super Admin

## User Roles
1. **Super Admin** - Full access to all companies and modules
2. **Company Admin** - Full control over assigned company
3. **HR Admin** - HR and recruitment module access
4. **Recruiter** - Recruitment and candidates only
5. **Manager** - Team-level access
6. **Employee** - Self-service only

## Role-Based Access Control (RBAC)

### Backend Middleware
Three-tier middleware approach applied to all API routes:
1. **requireAuth** - Verifies user is authenticated
2. **requireRole** - Checks user has one of the allowed roles
3. **requireModuleAccess** - Module-specific access control

### Module Access Configuration
| Module | Roles with Access |
|--------|-------------------|
| Companies | super_admin |
| Users | super_admin, company_admin |
| Employees | super_admin, company_admin, hr_admin, manager |
| Attendance | All authenticated users |
| Leave | All authenticated users |
| Payroll | super_admin, company_admin, hr_admin |
| Settings | super_admin, company_admin |

### Multi-Tenant Data Isolation
- **Super Admin**: Can access all companies' data
- **Other Roles**: Restricted to their own company's data only
- All CRUD operations validate company ownership before allowing changes
- EmployeeId query params are validated to prevent cross-company data access
- System-level settings (companyId=null) can only be modified by super_admin

### Frontend UI Filtering
- Sidebar menu items are filtered based on user role
- Only accessible modules are displayed to each user

## Development

### Running the Application
```bash
npm run dev
```

The application runs on port 5000 with both frontend and backend served from the same port.

## Completed Features

### Phase 1: Core Management
- Company CRUD with India compliance fields
- User management with role-based access
- Employee master with statutory information
- Session-based authentication

### Phase 2: HR Modules
- **Attendance Management**: Clock in/out tracking, monthly calendar view, status indicators
- **Leave Management**: Leave types, request submission, approval workflow
- **Payroll Processing**: Salary structures, monthly payroll generation, earnings/deductions with auto-calculation of statutory deductions (PF, ESI, PT) based on company settings and employee applicability flags
- **Settings**: General, localization, notifications, security configurations
- **Master Data Management**: Company-specific departments, designations, locations, earning heads, and deduction heads
- **Statutory Settings**: Configurable PF (12%/12%, ₹15k ceiling), ESIC (0.75%/3.25%, ₹21k ceiling), LWF (state-specific amounts), and PT (state-based, max ₹200/month)

## Known MVP Limitations
- Passwords stored in plain text (for demo purposes only)
- In-memory storage resets on server restart
- No file upload for company logos
- No email notifications (UI only)

## Future Phases
- Phase 3: Reports & Analytics
- Phase 4: Advanced Compliance & Integrations
