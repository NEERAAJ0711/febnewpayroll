import { pgTable, text, varchar, boolean, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Roles for the system
export const roles = [
  "super_admin",
  "company_admin", 
  "hr_admin",
  "recruiter",
  "manager",
  "employee"
] as const;

export type Role = typeof roles[number];

// Company Master
export const companies = pgTable("companies", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyName: text("company_name").notNull(),
  legalName: text("legal_name").notNull(),
  cin: text("cin"),
  pan: text("pan"),
  gstin: text("gstin"),
  pfCode: text("pf_code"),
  esiCode: text("esi_code"),
  ptState: text("pt_state"),
  lwfState: text("lwf_state"),
  registeredAddress: text("registered_address"),
  logo: text("logo"),
  financialYear: text("financial_year"),
  status: text("status").notNull().default("active"),
});

export const insertCompanySchema = createInsertSchema(companies).omit({ id: true });
export type InsertCompany = z.infer<typeof insertCompanySchema>;
export type Company = typeof companies.$inferSelect;

// Users table
export const users = pgTable("users", {
  id: varchar("id", { length: 36 }).primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name").default(""),
  lastName: text("last_name").default(""),
  role: text("role").notNull().default("employee"),
  companyId: varchar("company_id", { length: 36 }),
  status: text("status").notNull().default("active"),
  lastLogin: text("last_login"),
});

export const insertUserSchema = createInsertSchema(users).omit({ id: true, lastLogin: true });
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Employees table
export const employees = pgTable("employees", {
  id: varchar("id", { length: 36 }).primaryKey(),
  employeeCode: text("employee_code").notNull(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  userId: varchar("user_id", { length: 36 }),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  gender: text("gender"),
  dateOfBirth: text("date_of_birth"),
  mobileNumber: text("mobile_number"),
  officialEmail: text("official_email"),
  dateOfJoining: text("date_of_joining").notNull(),
  department: text("department"),
  designation: text("designation"),
  reportingManager: varchar("reporting_manager", { length: 36 }),
  location: text("location"),
  employmentType: text("employment_type").default("permanent"),
  status: text("status").notNull().default("active"),
  grossSalary: integer("gross_salary"),
  paymentMode: text("payment_mode"),
  pfApplicable: boolean("pf_applicable").default(false),
  uan: text("uan"),
  esiApplicable: boolean("esi_applicable").default(false),
  esiNumber: text("esi_number"),
  ptState: text("pt_state"),
  lwfApplicable: boolean("lwf_applicable").default(false),
  bankAccount: text("bank_account"),
  ifsc: text("ifsc"),
  pan: text("pan"),
  aadhaar: text("aadhaar"),
});

export const insertEmployeeSchema = createInsertSchema(employees).omit({ id: true });
export type InsertEmployee = z.infer<typeof insertEmployeeSchema>;
export type Employee = typeof employees.$inferSelect;

// Master Departments table (company-specific)
export const masterDepartments = pgTable("master_departments", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  name: text("name").notNull(),
  code: text("code"),
  description: text("description"),
  status: text("status").notNull().default("active"),
});

export const insertMasterDepartmentSchema = createInsertSchema(masterDepartments).omit({ id: true });
export type InsertMasterDepartment = z.infer<typeof insertMasterDepartmentSchema>;
export type MasterDepartment = typeof masterDepartments.$inferSelect;

// Master Designations table (company-specific)
export const masterDesignations = pgTable("master_designations", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  name: text("name").notNull(),
  code: text("code"),
  level: integer("level").default(1),
  description: text("description"),
  status: text("status").notNull().default("active"),
});

export const insertMasterDesignationSchema = createInsertSchema(masterDesignations).omit({ id: true });
export type InsertMasterDesignation = z.infer<typeof insertMasterDesignationSchema>;
export type MasterDesignation = typeof masterDesignations.$inferSelect;

// Master Locations table (company-specific)
export const masterLocations = pgTable("master_locations", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  name: text("name").notNull(),
  code: text("code"),
  address: text("address"),
  city: text("city"),
  state: text("state"),
  country: text("country").default("India"),
  status: text("status").notNull().default("active"),
});

export const insertMasterLocationSchema = createInsertSchema(masterLocations).omit({ id: true });
export type InsertMasterLocation = z.infer<typeof insertMasterLocationSchema>;
export type MasterLocation = typeof masterLocations.$inferSelect;

// Earning Heads table (company-specific)
export const earningHeads = pgTable("earning_heads", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  type: text("type").notNull().default("fixed"), // fixed, percentage
  calculationBase: text("calculation_base"), // basic, gross
  percentage: integer("percentage").default(0),
  isTaxable: boolean("is_taxable").default(true),
  isPartOfCTC: boolean("is_part_of_ctc").default(true),
  status: text("status").notNull().default("active"),
});

export const insertEarningHeadSchema = createInsertSchema(earningHeads).omit({ id: true });
export type InsertEarningHead = z.infer<typeof insertEarningHeadSchema>;
export type EarningHead = typeof earningHeads.$inferSelect;

// Deduction Heads table (company-specific)
export const deductionHeads = pgTable("deduction_heads", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  name: text("name").notNull(),
  code: text("code").notNull(),
  type: text("type").notNull().default("fixed"), // fixed, percentage
  calculationBase: text("calculation_base"), // basic, gross
  percentage: integer("percentage").default(0),
  isStatutory: boolean("is_statutory").default(false),
  status: text("status").notNull().default("active"),
});

export const insertDeductionHeadSchema = createInsertSchema(deductionHeads).omit({ id: true });
export type InsertDeductionHead = z.infer<typeof insertDeductionHeadSchema>;
export type DeductionHead = typeof deductionHeads.$inferSelect;

// Statutory Settings table (company-specific)
export const statutorySettings = pgTable("statutory_settings", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  // PF Settings
  pfEmployeePercent: integer("pf_employee_percent").default(12),
  pfEmployerPercent: integer("pf_employer_percent").default(12),
  pfWageCeiling: integer("pf_wage_ceiling").default(15000),
  pfEnabled: boolean("pf_enabled").default(true),
  // ESIC Settings
  esicEmployeePercent: integer("esic_employee_percent").default(75), // 0.75% stored as 75
  esicEmployerPercent: integer("esic_employer_percent").default(325), // 3.25% stored as 325
  esicWageCeiling: integer("esic_wage_ceiling").default(21000),
  esicEnabled: boolean("esic_enabled").default(true),
  // LWF Settings
  lwfEmployeeAmount: integer("lwf_employee_amount").default(0),
  lwfEmployerAmount: integer("lwf_employer_amount").default(0),
  lwfEnabled: boolean("lwf_enabled").default(false),
  // PT Settings (monthly slab-based, storing max amount)
  ptMaxAmount: integer("pt_max_amount").default(200),
  ptEnabled: boolean("pt_enabled").default(true),
  ptState: text("pt_state"),
});

export const insertStatutorySettingsSchema = createInsertSchema(statutorySettings).omit({ id: true });
export type InsertStatutorySettings = z.infer<typeof insertStatutorySettingsSchema>;
export type StatutorySettings = typeof statutorySettings.$inferSelect;

// Legacy departments array for backward compatibility
export const departments = [
  "Engineering",
  "Human Resources",
  "Finance",
  "Sales",
  "Marketing",
  "Operations",
  "Legal",
  "Administration"
] as const;

export type Department = typeof departments[number];

// Employment types
export const employmentTypes = [
  "permanent",
  "contract",
  "intern",
  "consultant"
] as const;

export type EmploymentType = typeof employmentTypes[number];

// Status types
export const statusTypes = ["active", "inactive"] as const;
export type StatusType = typeof statusTypes[number];

// Dashboard stats type
export interface DashboardStats {
  totalCompanies: number;
  totalEmployees: number;
  totalUsers: number;
  activeEmployees: number;
  departmentDistribution: { department: string; count: number }[];
  recentEmployees: Employee[];
}

// Attendance table
export const attendance = pgTable("attendance", {
  id: varchar("id", { length: 36 }).primaryKey(),
  employeeId: varchar("employee_id", { length: 36 }).notNull(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  date: text("date").notNull(),
  clockIn: text("clock_in"),
  clockOut: text("clock_out"),
  status: text("status").notNull().default("present"),
  workHours: text("work_hours"),
  notes: text("notes"),
});

export const insertAttendanceSchema = createInsertSchema(attendance).omit({ id: true });
export type InsertAttendance = z.infer<typeof insertAttendanceSchema>;
export type Attendance = typeof attendance.$inferSelect;

export const attendanceStatuses = ["present", "absent", "half_day", "on_leave", "holiday", "weekend"] as const;
export type AttendanceStatus = typeof attendanceStatuses[number];

// Leave Types table
export const leaveTypes = pgTable("leave_types", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyId: varchar("company_id", { length: 36 }),
  name: text("name").notNull(),
  code: text("code").notNull(),
  daysPerYear: integer("days_per_year").notNull().default(12),
  carryForward: boolean("carry_forward").default(false),
  maxCarryForward: integer("max_carry_forward").default(0),
  description: text("description"),
  status: text("status").notNull().default("active"),
});

export const insertLeaveTypeSchema = createInsertSchema(leaveTypes).omit({ id: true });
export type InsertLeaveType = z.infer<typeof insertLeaveTypeSchema>;
export type LeaveType = typeof leaveTypes.$inferSelect;

// Leave Requests table
export const leaveRequests = pgTable("leave_requests", {
  id: varchar("id", { length: 36 }).primaryKey(),
  employeeId: varchar("employee_id", { length: 36 }).notNull(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  leaveTypeId: varchar("leave_type_id", { length: 36 }).notNull(),
  startDate: text("start_date").notNull(),
  endDate: text("end_date").notNull(),
  days: integer("days").notNull(),
  reason: text("reason"),
  status: text("status").notNull().default("pending"),
  approvedBy: varchar("approved_by", { length: 36 }),
  approvedAt: text("approved_at"),
  createdAt: text("created_at").notNull(),
});

export const insertLeaveRequestSchema = createInsertSchema(leaveRequests).omit({ id: true, approvedBy: true, approvedAt: true });
export type InsertLeaveRequest = z.infer<typeof insertLeaveRequestSchema>;
export type LeaveRequest = typeof leaveRequests.$inferSelect;

export const leaveRequestStatuses = ["pending", "approved", "rejected", "cancelled"] as const;
export type LeaveRequestStatus = typeof leaveRequestStatuses[number];

// Salary Structure table
export const salaryStructures = pgTable("salary_structures", {
  id: varchar("id", { length: 36 }).primaryKey(),
  employeeId: varchar("employee_id", { length: 36 }).notNull(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  basicSalary: integer("basic_salary").notNull(),
  hra: integer("hra").default(0),
  conveyance: integer("conveyance").default(0),
  medicalAllowance: integer("medical_allowance").default(0),
  specialAllowance: integer("special_allowance").default(0),
  otherAllowances: integer("other_allowances").default(0),
  grossSalary: integer("gross_salary").notNull(),
  pfEmployee: integer("pf_employee").default(0),
  pfEmployer: integer("pf_employer").default(0),
  esi: integer("esi").default(0),
  professionalTax: integer("professional_tax").default(0),
  tds: integer("tds").default(0),
  otherDeductions: integer("other_deductions").default(0),
  netSalary: integer("net_salary").notNull(),
  effectiveFrom: text("effective_from").notNull(),
  status: text("status").notNull().default("active"),
});

export const insertSalaryStructureSchema = createInsertSchema(salaryStructures).omit({ id: true });
export type InsertSalaryStructure = z.infer<typeof insertSalaryStructureSchema>;
export type SalaryStructure = typeof salaryStructures.$inferSelect;

// Payroll table
export const payroll = pgTable("payroll", {
  id: varchar("id", { length: 36 }).primaryKey(),
  employeeId: varchar("employee_id", { length: 36 }).notNull(),
  companyId: varchar("company_id", { length: 36 }).notNull(),
  month: text("month").notNull(),
  year: integer("year").notNull(),
  basicSalary: integer("basic_salary").notNull(),
  totalEarnings: integer("total_earnings").notNull(),
  totalDeductions: integer("total_deductions").notNull(),
  netSalary: integer("net_salary").notNull(),
  workingDays: integer("working_days").notNull(),
  presentDays: integer("present_days").notNull(),
  leaveDays: integer("leave_days").default(0),
  status: text("status").notNull().default("draft"),
  paidOn: text("paid_on"),
  generatedAt: text("generated_at").notNull(),
});

export const insertPayrollSchema = createInsertSchema(payroll).omit({ id: true });
export type InsertPayroll = z.infer<typeof insertPayrollSchema>;
export type Payroll = typeof payroll.$inferSelect;

export const payrollStatuses = ["draft", "processed", "paid"] as const;
export type PayrollStatus = typeof payrollStatuses[number];

// Settings table
export const settings = pgTable("settings", {
  id: varchar("id", { length: 36 }).primaryKey(),
  companyId: varchar("company_id", { length: 36 }),
  key: text("key").notNull(),
  value: text("value"),
  category: text("category").notNull(),
});

export const insertSettingSchema = createInsertSchema(settings).omit({ id: true });
export type InsertSetting = z.infer<typeof insertSettingSchema>;
export type Setting = typeof settings.$inferSelect;
